-- Skema D1 (SQLite) untuk Garbarata OPS.
-- Aman dijalankan ulang: memakai IF NOT EXISTS.

CREATE TABLE IF NOT EXISTS users (
  id              TEXT PRIMARY KEY,
  login_id        TEXT NOT NULL UNIQUE COLLATE NOCASE,
  full_name       TEXT NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('admin', 'operator', 'supervisor')),
  pin_hash        TEXT NOT NULL,
  active          INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until    TEXT,
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS user_sessions (
  id_hash    TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user    ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires ON user_sessions(expires_at);

CREATE TABLE IF NOT EXISTS operations (
  id                    TEXT PRIMARY KEY,
  flight_number         TEXT NOT NULL DEFAULT '',
  aircraft_registration TEXT NOT NULL,
  parking_stand         TEXT NOT NULL,
  activity              TEXT NOT NULL CHECK (activity IN ('Docking', 'Undocking')),
  activity_time         TEXT NOT NULL,
  operator_id           TEXT NOT NULL REFERENCES users(id),
  deleted_at            TEXT,
  deleted_by            TEXT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_operations_time     ON operations(deleted_at, activity_time DESC);
CREATE INDEX IF NOT EXISTS idx_operations_operator ON operations(operator_id, activity_time);

CREATE TABLE IF NOT EXISTS operation_notes (
  operation_id TEXT PRIMARY KEY REFERENCES operations(id) ON DELETE CASCADE,
  author_id    TEXT NOT NULL REFERENCES users(id),
  note         TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
