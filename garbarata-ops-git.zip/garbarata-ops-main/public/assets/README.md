supabase.js is the browser UMD distribution of @supabase/supabase-js 2.119.0, served locally so login does not require a third-party CDN at runtime.

Source: https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.119.0/dist/umd/supabase.js
License: MIT. See supabase.LICENSE.
