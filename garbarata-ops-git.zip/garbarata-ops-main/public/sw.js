// Garbarata OPS service worker: membuat aplikasi bisa di-install di Android
// dan menjaga app shell tetap tersedia saat koneksi lemah. Permintaan API,
// login, dan halaman setup TIDAK pernah di-cache supaya data dan sesi selalu
// berasal dari server.
const CACHE = 'garbarata-ops-v2';
const SHELL = [
  '/',
  '/manifest.webmanifest',
  '/assets/app-icons/icon-192.png',
  '/assets/app-icons/icon-512.png',
  '/assets/app-icons/favicon-64.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/setup-admin') return;

  if (request.mode === 'navigate') {
    // Network first agar operator selalu mendapat versi terbaru.
    // Hanya halaman utama ("/") yang disimpan sebagai cadangan offline.
    event.respondWith(
      fetch(request)
        .then(response => {
          if (response.ok && url.pathname === '/') {
            const copy = response.clone();
            caches.open(CACHE).then(cache => cache.put('/', copy));
          }
          return response;
        })
        .catch(() => caches.match('/'))
    );
    return;
  }

  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.match(request).then(cached => cached || fetch(request).then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then(cache => cache.put(request, copy));
        }
        return response;
      }))
    );
  }
});
