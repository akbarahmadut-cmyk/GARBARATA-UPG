// Garbarata OPS - Cloudflare Worker (Workers + D1 + Static Assets)
//
// File statis (public/) dilayani langsung oleh Cloudflare. Worker ini hanya
// menangani /api/* dan /setup-admin. Semua hak akses diperiksa di server.

const SESSION_SECONDS = 5 * 60 * 60;
const COOKIE = "__Host-ops_session";
const PIN_ITERATIONS = 100000; // batas maksimum PBKDF2 di Cloudflare Workers
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;
const PAGE_SIZE = 10;
const ROLES = ["admin", "operator", "supervisor"];
const UUID_RE = /^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i;
const LOGIN_ID_RE = /^[A-Z0-9._-]{3,32}$/;
const PIN_RE = /^\d{6,12}$/;
const DUMMY_SALT = "00".repeat(16);

const LOGIN_ID_ERROR =
  "ID login 3–32 karakter: huruf, angka, titik, garis bawah, atau tanda hubung.";
const PIN_ERROR = "PIN harus 6–12 digit angka.";

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// ---------------------------------------------------------------- helpers

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...headers
    }
  });
}

function errorResponse(message, status = 400, headers = {}) {
  return json({ error: message }, status, headers);
}

async function readBody(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    throw new HttpError(400, "Data permintaan tidak valid.");
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new HttpError(400, "Data permintaan tidak valid.");
  }
  return body;
}

function allowMethods(request, methods) {
  if (!methods.includes(request.method)) {
    throw new HttpError(405, "Metode tidak diizinkan.");
  }
}

function requireSameOrigin(request) {
  const origin = request.headers.get("Origin");
  if (origin && origin !== new URL(request.url).origin) {
    throw new HttpError(403, "Permintaan tidak diizinkan.");
  }
}

function toHex(buffer) {
  return [...new Uint8Array(buffer)]
    .map(x => x.toString(16).padStart(2, "0")).join("");
}

function randomHex(bytes = 32) {
  return toHex(crypto.getRandomValues(new Uint8Array(bytes)));
}

async function sha256(value) {
  return toHex(await crypto.subtle.digest(
    "SHA-256", new TextEncoder().encode(value)
  ));
}

async function pinHash(pin, saltHex, iterations = PIN_ITERATIONS) {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits({
    name: "PBKDF2",
    salt: Uint8Array.from(saltHex.match(/.{2}/g).map(x => parseInt(x, 16))),
    iterations,
    hash: "SHA-256"
  }, key, 256);
  return toHex(bits);
}

async function createPinHash(pin) {
  const salt = randomHex(16);
  return `pbkdf2$${PIN_ITERATIONS}$${salt}$${await pinHash(pin, salt)}`;
}

async function verifyPin(pin, stored) {
  try {
    const [algorithm, iterations, salt, expected] = String(stored).split("$");
    if (algorithm !== "pbkdf2" || !salt || !expected) return false;

    const actual = await pinHash(pin, salt, Number(iterations));
    if (actual.length !== expected.length) return false;

    let difference = 0;
    for (let i = 0; i < actual.length; i++) {
      difference |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
    }
    return difference === 0;
  } catch {
    return false;
  }
}

const normalizeLoginId = value =>
  typeof value === "string" ? value.trim().toUpperCase() : "";

function publicUser(row) {
  return {
    id: row.id,
    login_id: row.login_id,
    full_name: row.full_name,
    role: row.role,
    active: row.active === 1
  };
}

// ---------------------------------------------------------------- sesi

function getCookie(request) {
  const item = (request.headers.get("Cookie") || "")
    .split(";").map(x => x.trim())
    .find(x => x.startsWith(COOKIE + "="));
  return item ? item.slice(COOKIE.length + 1) : null;
}

function sessionCookie(token) {
  return `${COOKIE}=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${SESSION_SECONDS}`;
}

const clearedCookie =
  `${COOKIE}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`;

async function startSession(env, userId) {
  const token = randomHex(32);

  // Bersihkan sesi kedaluwarsa agar tabel tidak membengkak.
  await env.DB.prepare("DELETE FROM user_sessions WHERE expires_at <= ?")
    .bind(new Date().toISOString()).run();

  await env.DB.prepare(
    "INSERT INTO user_sessions (id_hash, user_id, expires_at) VALUES (?, ?, ?)"
  ).bind(
    await sha256(token),
    userId,
    new Date(Date.now() + SESSION_SECONDS * 1000).toISOString()
  ).run();

  return token;
}

async function endSessionsFor(env, userId) {
  await env.DB.prepare("DELETE FROM user_sessions WHERE user_id = ?")
    .bind(userId).run();
}

async function currentUser(request, env) {
  const token = getCookie(request);
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;

  const session = await env.DB.prepare(
    "SELECT user_id FROM user_sessions WHERE id_hash = ? AND expires_at > ?"
  ).bind(await sha256(token), new Date().toISOString()).first();
  if (!session) return null;

  const user = await env.DB.prepare(
    "SELECT id, login_id, full_name, role, active FROM users WHERE id = ?"
  ).bind(session.user_id).first();

  return user && user.active === 1 ? user : null;
}

async function requireUser(request, env) {
  const user = await currentUser(request, env);
  if (!user) {
    throw new HttpError(401, "Sesi telah berakhir. Silakan masuk kembali.");
  }
  return user;
}

// ---------------------------------------------------------------- shift WITA

function operatorShift(now) {
  const local = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  const hour = local.getUTCHours();
  const startHour = hour < 8 ? -4 : hour < 14 ? 8 : hour < 20 ? 14 : 20;

  const start = Date.UTC(
    local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate(), startHour
  ) - 8 * 60 * 60 * 1000;

  const length = startHour === -4 || startHour === 20 ? 12 : 6;
  return {
    start: new Date(start).toISOString(),
    end: new Date(start + length * 60 * 60 * 1000).toISOString()
  };
}

// ---------------------------------------------------------------- setup admin

async function health(request, env) {
  allowMethods(request, ["GET"]);
  try {
    await env.DB.prepare("SELECT 1").first();
    return json({ status: "ok", database: "connected" });
  } catch (e) {
    console.error("Health check gagal:", e);
    return json({ status: "error", database: "unavailable" }, 503);
  }
}

async function setupPage(request, env) {
  allowMethods(request, ["GET"]);
  const count = await env.DB.prepare(
    "SELECT COUNT(*) AS total FROM users"
  ).first();

  const headers = {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff"
  };

  if (count.total > 0) {
    return new Response(
      "<!DOCTYPE html><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
      "<h2>Admin sudah dibuat.</h2><p>Pembuatan Admin pertama telah ditutup. <a href=\"/\">Kembali ke aplikasi</a></p>",
      { headers }
    );
  }

  return new Response(`<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Setup Admin Garbarata OPS</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f5f8;padding:20px}
main{max-width:420px;margin:35px auto;background:white;padding:24px;border-radius:14px}
input{box-sizing:border-box;width:100%;padding:13px;margin:7px 0 15px;border:1px solid #ccc;border-radius:7px}
button{width:100%;padding:14px;background:#1769d2;color:white;border:0;border-radius:7px;font-weight:bold}
#message{margin-top:15px}
</style>
</head>
<body>
<main>
<h2>Garbarata OPS</h2>
<h3>Buat Admin Pertama</h3>
<p>Isi data Admin utama aplikasi.</p>

<form id="setup">
<label for="login">ID Admin</label>
<input id="login" required minlength="3" maxlength="32" autocomplete="username" autocapitalize="characters">

<label for="name">Nama Admin</label>
<input id="name" required maxlength="100" autocomplete="name">

<label for="pin">PIN (6–12 digit)</label>
<input id="pin" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="new-password">

<button id="submit">Buat Admin</button>
</form>

<div id="message" role="status"></div>
</main>

<script>
document.getElementById("setup").addEventListener("submit", async e => {
  e.preventDefault();
  const button = document.getElementById("submit");
  const message = document.getElementById("message");
  button.disabled = true;
  button.textContent = "Memproses...";
  message.textContent = "";
  try {
    const response = await fetch("/api/setup-admin", {
      method: "POST",
      credentials: "same-origin",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        login_id: document.getElementById("login").value,
        full_name: document.getElementById("name").value,
        pin: document.getElementById("pin").value
      })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || "Gagal membuat Admin.");
    message.textContent = "Admin berhasil dibuat. Membuka aplikasi...";
    setTimeout(() => { window.location.href = "/"; }, 800);
  } catch (err) {
    message.textContent = err.message;
    button.disabled = false;
    button.textContent = "Buat Admin";
  }
});
</script>
</body>
</html>`, { headers });
}

async function setupAdmin(request, env) {
  allowMethods(request, ["POST"]);
  // Endpoint ini wajib berasal dari halaman sendiri.
  if (request.headers.get("Origin") !== new URL(request.url).origin) {
    throw new HttpError(403, "Permintaan tidak diizinkan.");
  }

  const body = await readBody(request);
  const loginId = normalizeLoginId(body.login_id);
  const fullName = typeof body.full_name === "string" ? body.full_name.trim() : "";
  const pin = typeof body.pin === "string" ? body.pin : "";

  if (!LOGIN_ID_RE.test(loginId)) throw new HttpError(400, LOGIN_ID_ERROR);
  if (!fullName || fullName.length > 100) {
    throw new HttpError(400, "Nama Admin wajib diisi, maksimal 100 karakter.");
  }
  if (!PIN_RE.test(pin)) throw new HttpError(400, PIN_ERROR);

  const id = crypto.randomUUID();
  const hashed = await createPinHash(pin);

  // INSERT ... WHERE NOT EXISTS membuat pembuatan admin pertama atomik.
  const result = await env.DB.prepare(`
    INSERT INTO users (id, login_id, full_name, role, pin_hash, active)
    SELECT ?, ?, ?, 'admin', ?, 1
    WHERE NOT EXISTS (SELECT 1 FROM users)
  `).bind(id, loginId, fullName, hashed).run();

  if (result.meta.changes !== 1) {
    throw new HttpError(409, "Admin pertama sudah dibuat. Pendaftaran ditutup.");
  }

  const token = await startSession(env, id);
  return json({
    ok: true,
    user: { id, login_id: loginId, full_name: fullName, role: "admin", active: true }
  }, 201, { "Set-Cookie": sessionCookie(token) });
}

// ---------------------------------------------------------------- login/sesi

async function login(env, body) {
  const loginId = normalizeLoginId(body.login_id);
  const pin = typeof body.pin === "string" ? body.pin : "";
  const invalid = "ID atau PIN salah.";

  if (!LOGIN_ID_RE.test(loginId) || !PIN_RE.test(pin)) {
    throw new HttpError(401, invalid);
  }

  const user = await env.DB.prepare(
    "SELECT * FROM users WHERE login_id = ?"
  ).bind(loginId).first();

  if (!user) {
    // Hash palsu agar waktu respons tidak membedakan ID yang tidak ada.
    await pinHash(pin, DUMMY_SALT);
    throw new HttpError(401, invalid);
  }

  if (user.locked_until) {
    if (Date.parse(user.locked_until) > Date.now()) {
      throw new HttpError(
        423,
        "Terlalu banyak percobaan. Akun dikunci sementara, coba lagi nanti atau hubungi admin."
      );
    }
    // Masa kunci sudah habis: hitungan percobaan dimulai dari nol.
    await env.DB.prepare(
      "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?"
    ).bind(user.id).run();
    user.failed_attempts = 0;
  }

  if (!(await verifyPin(pin, user.pin_hash))) {
    await env.DB.prepare(`
      UPDATE users
      SET failed_attempts = failed_attempts + 1,
          locked_until = CASE WHEN failed_attempts + 1 >= ? THEN ? ELSE NULL END
      WHERE id = ?
    `).bind(
      MAX_FAILED_ATTEMPTS,
      new Date(Date.now() + LOCK_MINUTES * 60 * 1000).toISOString(),
      user.id
    ).run();
    throw new HttpError(401, invalid);
  }

  if (user.active !== 1) {
    throw new HttpError(403, "Akun dinonaktifkan. Hubungi admin.");
  }

  if (user.failed_attempts) {
    await env.DB.prepare(
      "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?"
    ).bind(user.id).run();
  }

  const token = await startSession(env, user.id);
  return json({ ok: true, user: publicUser(user) }, 200, {
    "Set-Cookie": sessionCookie(token)
  });
}

async function sessionRoute(request, env) {
  allowMethods(request, ["GET", "POST"]);

  if (request.method === "GET") {
    return json(publicUser(await requireUser(request, env)));
  }

  requireSameOrigin(request);
  const body = await readBody(request);

  if (body.action === "logout") {
    const token = getCookie(request);
    if (token && /^[a-f0-9]{64}$/.test(token)) {
      await env.DB.prepare("DELETE FROM user_sessions WHERE id_hash = ?")
        .bind(await sha256(token)).run();
    }
    return json({ ok: true }, 200, { "Set-Cookie": clearedCookie });
  }

  if (body.action === "staff-login" || body.action === "login") {
    return login(env, body);
  }

  throw new HttpError(400, "Permintaan tidak valid.");
}

// ---------------------------------------------------------------- operasional

async function operationsRoute(request, env) {
  allowMethods(request, ["GET", "POST", "DELETE"]);
  const user = await requireUser(request, env);

  if (request.method === "GET") {
    const now = new Date();
    const leaderboardShift = operatorShift(now);
    const shift = user.role === "operator" ? leaderboardShift : null;

    const requested = Number(new URL(request.url).searchParams.get("page") || "1");
    if (!Number.isSafeInteger(requested) || requested < 1) {
      throw new HttpError(400, "Halaman tidak valid.");
    }

    const where = "deleted_at IS NULL" +
      (shift ? " AND activity_time >= ? AND activity_time < ?" : "");
    const params = shift ? [shift.start, shift.end] : [];

    const grouped = await env.DB.prepare(
      `SELECT activity, COUNT(*) AS total FROM operations WHERE ${where} GROUP BY activity`
    ).bind(...params).all();

    const countOf = name =>
      grouped.results.find(row => row.activity === name)?.total ?? 0;
    const total = grouped.results.reduce((sum, row) => sum + row.total, 0);
    const stats = { total, docking: countOf("Docking"), undocking: countOf("Undocking") };

    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const page = Math.min(requested, totalPages);

    const rows = await env.DB.prepare(`
      SELECT id, flight_number, aircraft_registration, parking_stand,
             activity, activity_time, operator_id
      FROM operations WHERE ${where}
      ORDER BY activity_time DESC, id DESC
      LIMIT ${PAGE_SIZE} OFFSET ?
    `).bind(...params, (page - 1) * PAGE_SIZE).all();

    const shiftTotals = await env.DB.prepare(`
      SELECT operator_id, COUNT(*) AS total FROM operations
      WHERE deleted_at IS NULL AND activity_time >= ? AND activity_time < ?
      GROUP BY operator_id
    `).bind(leaderboardShift.start, leaderboardShift.end).all();
    const counts = new Map(shiftTotals.results.map(r => [r.operator_id, r.total]));

    const users = await env.DB.prepare(
      "SELECT id, full_name, role, active FROM users"
    ).all();

    const leaderboard = users.results
      .filter(u => u.role === "operator" && u.active === 1)
      .map(u => ({
        operator_id: u.id,
        name: u.full_name || u.id,
        total: counts.get(u.id) ?? 0
      }))
      .sort((a, b) =>
        b.total - a.total ||
        a.name.localeCompare(b.name, "id") ||
        a.operator_id.localeCompare(b.operator_id));

    return json({
      rows: rows.results,
      pagination: { page, pageSize: PAGE_SIZE, total, totalPages },
      stats,
      shift,
      leaderboard,
      leaderboardShift,
      serverTime: now.toISOString(),
      // Hanya data minimal untuk menampilkan nama operator.
      profiles: users.results.map(u => ({
        id: u.id, full_name: u.full_name, role: u.role
      }))
    });
  }

  requireSameOrigin(request);
  const body = await readBody(request);

  if (request.method === "DELETE") {
    if (!["admin", "supervisor"].includes(user.role)) {
      throw new HttpError(403, "Hanya admin dan supervisor dapat menghapus kegiatan.");
    }
    if (typeof body.id !== "string" || !UUID_RE.test(body.id)) {
      throw new HttpError(400, "ID tidak valid.");
    }
    await env.DB.prepare(`
      UPDATE operations SET deleted_at = ?, deleted_by = ?
      WHERE id = ? AND deleted_at IS NULL
    `).bind(new Date().toISOString(), user.id, body.id).run();
    return json({ ok: true });
  }

  // POST: kegiatan baru
  if (!["Docking", "Undocking"].includes(body.activity)) {
    throw new HttpError(400, "Aktivitas tidak valid.");
  }
  const registration = typeof body.aircraft_registration === "string"
    ? body.aircraft_registration.trim() : "";
  const stand = typeof body.parking_stand === "string"
    ? body.parking_stand.trim() : "";
  const time = typeof body.activity_time === "string"
    ? Date.parse(body.activity_time) : NaN;

  if (!registration || registration.length > 100 ||
      !stand || stand.length > 100 || !Number.isFinite(time)) {
    throw new HttpError(
      400, "Lengkapi registrasi, stand, dan waktu kegiatan (maksimal 100 karakter per kolom)."
    );
  }

  const id = crypto.randomUUID();
  await env.DB.prepare(`
    INSERT INTO operations
      (id, flight_number, aircraft_registration, parking_stand,
       activity, activity_time, operator_id)
    VALUES (?, '', ?, ?, ?, ?, ?)
  `).bind(
    id, registration, stand, body.activity,
    new Date(time).toISOString(), user.id
  ).run();

  return json({ id }, 201);
}

// ---------------------------------------------------------------- catatan

async function notesRoute(request, env) {
  allowMethods(request, ["POST"]);
  requireSameOrigin(request);
  const user = await requireUser(request, env);
  const body = await readBody(request);

  // Simpan catatan untuk satu kegiatan milik operator itu sendiri.
  if (body.operationId !== undefined) {
    if (typeof body.operationId !== "string" || !UUID_RE.test(body.operationId)) {
      throw new HttpError(400, "ID kegiatan tidak valid.");
    }
    if (typeof body.note !== "string" || body.note.length > 2000) {
      throw new HttpError(400, "Catatan maksimal 2000 karakter.");
    }

    const operation = await env.DB.prepare(
      "SELECT operator_id FROM operations WHERE id = ? AND deleted_at IS NULL"
    ).bind(body.operationId).first();

    if (!operation || operation.operator_id !== user.id) {
      throw new HttpError(403, "Catatan hanya dapat disimpan oleh operator kegiatan.");
    }

    const note = body.note.trim();
    if (!note) {
      await env.DB.prepare("DELETE FROM operation_notes WHERE operation_id = ?")
        .bind(body.operationId).run();
    } else {
      await env.DB.prepare(`
        INSERT INTO operation_notes (operation_id, author_id, note, created_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(operation_id) DO UPDATE SET note = excluded.note
      `).bind(body.operationId, user.id, note, new Date().toISOString()).run();
    }
    return json({ ok: true });
  }

  // Ambil catatan untuk daftar kegiatan yang boleh dilihat user.
  const ids = body.ids;
  if (!Array.isArray(ids) || ids.length > 500 ||
      ids.some(id => typeof id !== "string" || !UUID_RE.test(id))) {
    throw new HttpError(400, "ID kegiatan tidak valid.");
  }

  const shift = user.role === "operator" ? operatorShift(new Date()) : null;
  const result = {};

  // D1 membatasi jumlah parameter per query, jadi diproses per 50 ID.
  for (let i = 0; i < ids.length; i += 50) {
    const chunk = ids.slice(i, i + 50);
    const marks = chunk.map(() => "?").join(",");
    const rows = await env.DB.prepare(`
      SELECT n.operation_id, n.note
      FROM operation_notes n
      JOIN operations o ON o.id = n.operation_id
      WHERE o.deleted_at IS NULL
        AND n.operation_id IN (${marks})
        ${shift ? "AND o.activity_time >= ? AND o.activity_time < ?" : ""}
    `).bind(...chunk, ...(shift ? [shift.start, shift.end] : [])).all();

    for (const row of rows.results) result[row.operation_id] = row.note;
  }

  return json(result);
}

// ---------------------------------------------------------------- rekap CSV

function monthBounds(month, offset) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month) ||
      Number(month.slice(0, 4)) < 2000 || !/^-?\d+$/.test(offset)) {
    throw new HttpError(400, "Pilih bulan yang valid.");
  }
  const minutes = Number(offset);
  if (minutes < -840 || minutes > 840) {
    throw new HttpError(400, "Zona waktu tidak valid.");
  }
  const [year, m] = month.split("-").map(Number);
  return [
    new Date(Date.UTC(year, m - 1, 1) + minutes * 60000).toISOString(),
    new Date(Date.UTC(year, m, 1) + minutes * 60000).toISOString()
  ];
}

// Sel yang diawali rumus (= + - @) diberi tanda petik agar tidak dieksekusi Excel.
function csvCell(value) {
  let text = String(value ?? "");
  if (/^[\s\uFEFF]*[=+@-]/.test(text) || /^[\t\r\n]/.test(text)) {
    text = "'" + text;
  }
  return '"' + text.replace(/"/g, '""') + '"';
}

async function exportRoute(request, env) {
  allowMethods(request, ["GET"]);
  const user = await requireUser(request, env);
  if (!["admin", "supervisor"].includes(user.role)) {
    throw new HttpError(403, "Unduhan hanya untuk admin dan supervisor.");
  }

  const params = new URL(request.url).searchParams;
  const month = params.get("month") ?? "";
  const offset = params.get("offset") ?? "0";
  const [start, end] = monthBounds(month, offset);

  const rows = await env.DB.prepare(`
    SELECT o.aircraft_registration, o.parking_stand, o.activity,
           o.activity_time, o.operator_id,
           u.full_name, u.login_id, n.note
    FROM operations o
    LEFT JOIN users u ON u.id = o.operator_id
    LEFT JOIN operation_notes n ON n.operation_id = o.id
    WHERE o.deleted_at IS NULL AND o.activity_time >= ? AND o.activity_time < ?
    ORDER BY o.activity_time ASC, o.id ASC
  `).bind(start, end).all();

  if (!rows.results.length) {
    throw new HttpError(404, "Tidak ada kegiatan pada bulan yang dipilih.");
  }

  const localTime = iso =>
    new Date(new Date(iso).getTime() - Number(offset) * 60000)
      .toISOString().slice(0, 19).replace("T", " ");

  const csv = [
    ["Registrasi", "Stand", "Aktivitas", "Waktu aktivitas (lokal)",
     "Operator ID", "Nama operator", "ID login operator", "Catatan"],
    ...rows.results.map(r => [
      r.aircraft_registration, r.parking_stand, r.activity,
      localTime(r.activity_time), r.operator_id,
      r.full_name, r.login_id, r.note
    ])
  ].map(line => line.map(csvCell).join(",")).join("\r\n");

  return new Response("\uFEFF" + csv + "\r\n", {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="rekap-operasional-${month}.csv"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff"
    }
  });
}

// ---------------------------------------------------------------- akun

async function accountsRoute(request, env) {
  allowMethods(request, ["GET", "POST", "PATCH"]);
  const actor = await requireUser(request, env);
  if (actor.role !== "admin") {
    throw new HttpError(403, "Pengelolaan user hanya untuk admin.");
  }

  if (request.method === "GET") {
    const users = await env.DB.prepare(`
      SELECT id, login_id, full_name, role, active FROM users
      ORDER BY full_name COLLATE NOCASE, login_id
    `).all();
    return json(users.results.map(publicUser));
  }

  requireSameOrigin(request);
  const body = await readBody(request);

  const name = typeof body.full_name === "string" ? body.full_name.trim() : "";
  if (!name || name.length > 100) {
    throw new HttpError(400, "Nama wajib diisi, maksimal 100 karakter.");
  }

  if (request.method === "POST") {
    if (!ROLES.includes(body.role)) {
      throw new HttpError(400, "Pilih peran admin, operator, atau supervisor.");
    }
    const loginId = normalizeLoginId(body.login_id);
    if (!LOGIN_ID_RE.test(loginId)) throw new HttpError(400, LOGIN_ID_ERROR);
    if (typeof body.pin !== "string" || !PIN_RE.test(body.pin)) {
      throw new HttpError(400, PIN_ERROR);
    }

    const id = crypto.randomUUID();
    const result = await env.DB.prepare(`
      INSERT INTO users (id, login_id, full_name, role, pin_hash, active)
      VALUES (?, ?, ?, ?, ?, 1)
      ON CONFLICT(login_id) DO NOTHING
    `).bind(id, loginId, name, body.role, await createPinHash(body.pin)).run();

    if (result.meta.changes !== 1) {
      throw new HttpError(409, "ID login sudah dipakai. Gunakan ID lain.");
    }
    return json(
      publicUser({ id, login_id: loginId, full_name: name, role: body.role, active: 1 }),
      201
    );
  }

  // PATCH: ubah nama, peran, PIN, atau status aktif
  if (typeof body.id !== "string" || !UUID_RE.test(body.id)) {
    throw new HttpError(400, "User tidak valid.");
  }
  const target = await env.DB.prepare("SELECT * FROM users WHERE id = ?")
    .bind(body.id).first();
  if (!target) throw new HttpError(404, "User tidak ditemukan.");

  const hasPin = body.pin !== undefined && body.pin !== "";
  if (hasPin && (typeof body.pin !== "string" || !PIN_RE.test(body.pin))) {
    throw new HttpError(400, PIN_ERROR);
  }
  if (body.role !== undefined && !ROLES.includes(body.role)) {
    throw new HttpError(400, "Pilih peran admin, operator, atau supervisor.");
  }
  if (body.active !== undefined && typeof body.active !== "boolean") {
    throw new HttpError(400, "Status akun tidak valid.");
  }

  const roleChanged = body.role !== undefined && body.role !== target.role;
  const deactivating = body.active === false && target.active === 1;
  if (target.id === actor.id && (roleChanged || body.active === false)) {
    throw new HttpError(400, "Anda tidak dapat mengubah peran atau menonaktifkan akun sendiri.");
  }

  const sets = ["full_name = ?"];
  const values = [name];
  if (body.role !== undefined) { sets.push("role = ?"); values.push(body.role); }
  if (body.active !== undefined) { sets.push("active = ?"); values.push(body.active ? 1 : 0); }
  if (hasPin) {
    sets.push("pin_hash = ?");
    values.push(await createPinHash(body.pin));
  }
  if (hasPin || body.active === true) {
    sets.push("failed_attempts = 0", "locked_until = NULL");
  }

  await env.DB.prepare(`UPDATE users SET ${sets.join(", ")} WHERE id = ?`)
    .bind(...values, target.id).run();

  // PIN baru, perubahan peran, atau penonaktifan langsung mengakhiri sesi akun.
  if (hasPin || roleChanged || deactivating) await endSessionsFor(env, target.id);

  const updated = await env.DB.prepare(
    "SELECT id, login_id, full_name, role, active FROM users WHERE id = ?"
  ).bind(target.id).first();
  return json(publicUser(updated));
}

// ---------------------------------------------------------------- router

const ROUTES = {
  "/api/health": health,
  "/setup-admin": setupPage,
  "/api/setup-admin": setupAdmin,
  "/api/session": sessionRoute,
  "/api/operations": operationsRoute,
  "/api/operation-notes": notesRoute,
  "/api/monthly-export": exportRoute,
  "/api/accounts": accountsRoute
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const handler = ROUTES[url.pathname];

    if (!handler) {
      if (url.pathname.startsWith("/api/")) {
        return errorResponse("Layanan tidak ditemukan.", 404);
      }
      return env.ASSETS.fetch(request);
    }

    try {
      return await handler(request, env);
    } catch (e) {
      if (e instanceof HttpError) return errorResponse(e.message, e.status);
      console.error("Worker error:", e);
      return errorResponse("Layanan sementara tidak tersedia. Silakan coba lagi.", 500);
    }
  }
};
