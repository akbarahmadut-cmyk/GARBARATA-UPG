import { boolean, integer, pgTable, text, timestamp, uuid } from 'drizzle-orm/pg-core';

export const operationNotes = pgTable('operation_notes', {
  operationId: uuid('operation_id').primaryKey(),
  authorId: uuid('author_id').notNull(),
  note: text('note').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

export const operations = pgTable('operations', {
  id: uuid('id').primaryKey().defaultRandom(),
  flight_number: text('flight_number').notNull(),
  aircraft_registration: text('aircraft_registration').notNull(),
  parking_stand: text('parking_stand').notNull(),
  activity: text('activity').notNull(),
  activity_time: timestamp('activity_time', { withTimezone: true, mode: 'string' }).notNull(),
  operator_id: uuid('operator_id').notNull(),
  deleted_at: timestamp('deleted_at', { withTimezone: true, mode: 'string' }),
  deleted_by: uuid('deleted_by'),
});

export const userSessions = pgTable('user_sessions', {
  idHash: text('id_hash').primaryKey(),
  userId: uuid('user_id').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
});

// Operator and supervisor accounts managed by admins; they sign in with a login ID and PIN, not Identity.
export const staffAccounts = pgTable('staff_accounts', {
  id: uuid('id').primaryKey().defaultRandom(),
  loginId: text('login_id').notNull().unique(),
  fullName: text('full_name').notNull(),
  role: text('role').notNull(),
  pinHash: text('pin_hash').notNull(),
  active: boolean('active').default(true).notNull(),
  failedAttempts: integer('failed_attempts').default(0).notNull(),
  lockedUntil: timestamp('locked_until', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});
