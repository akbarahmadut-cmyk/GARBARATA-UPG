import { sessionUserId } from './sessions.js';
import { staffStore, staffUser } from './staff.js';
import { admin, type User } from '@netlify/identity';
import { and, asc, gte, inArray, isNull, lt } from 'drizzle-orm';
import { database } from '../db/index.js';
import { operations } from '../db/schema.js';

export function userRole(user: User) {
  return ['admin','supervisor','operator'].find(role => user.appMetadata?.roles instanceof Array && user.appMetadata.roles.includes(role)) ?? '';
}
// Sultan Hasanuddin operates in WITA (UTC+08:00), independent of device timezone.
export function operatorShift(now = new Date()) {
  const local = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  const hour = local.getUTCHours();
  const startHour = hour < 8 ? -4 : hour < 14 ? 8 : hour < 20 ? 14 : 20;
  const start = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate(), startHour) - 8 * 60 * 60 * 1000;
  const end = start + (startHour === -4 || startHour === 20 ? 12 : 6) * 60 * 60 * 1000;
  return { start: new Date(start).toISOString(), end: new Date(end).toISOString() };
}
export async function identityUser() {
  // The server-side session remains authoritative when the shorter Identity JWT expires.
  const userId = await sessionUserId();
  if (!userId) throw new HttpError(401, 'Sesi telah berakhir. Silakan masuk kembali.');
  const staff = await staffStore.byId(userId);
  if (staff && !staff.active) throw new HttpError(401, 'Akun dinonaktifkan. Hubungi admin.');
  const user = staff ? staffUser(staff) : await admin.getUser(userId);
  if (!userRole(user)) throw new HttpError(403, 'Akun belum memiliki peran. Hubungi admin.');
  return user;
}
export function publicUser(user: User) {
  const staff = user.appMetadata?.staff === true;
  return {id:user.id, email:user.email, full_name:String(user.userMetadata?.full_name || user.name || ''), role:userRole(user),
    ...(staff ? {login_id:String(user.userMetadata?.login_id ?? ''), active:user.appMetadata?.active !== false, staff:true} : {})};
}
export async function allUsers() {
  const users: User[] = (await staffStore.all()).map(staffUser);
  for (let page=1;;page++) {
    const batch = await admin.listUsers({page,perPage:100});
    users.push(...batch);
    if (batch.length < 100) return users;
  }
}
export function sameOrigin(req: Request) {
  if (req.headers.get('origin') !== new URL(req.url).origin) throw new HttpError(403, 'Permintaan tidak diizinkan.');
}
export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export function upstream(_req: Request) {
  return async (path: string): Promise<any> => {
    const user = await identityUser();
    const query = new URL('https://local/' + path).searchParams;
    if (path === 'auth/v1/user') return user;
    if (path.startsWith('rest/v1/profiles')) {
      if (query.get('select') === 'role') return [{ role: userRole(user) }];
      const users = await allUsers();
      return users.map(publicUser);
    }
    let condition = isNull(operations.deleted_at);
    if (query.get('id')?.startsWith('in.(')) {
      const ids = query.get('id')!.slice(4,-1).split(',');
      condition = and(condition, inArray(operations.id, ids))!;
    }
    if (query.get('and')) {
      const match = query.get('and')!.match(/activity_time.gte.(.*),activity_time.lt.(.*)\)/);
      if (match) condition = and(condition, gte(operations.activity_time, match[1]), lt(operations.activity_time, match[2]))!;
    }
    return database().select().from(operations).where(condition)
      .orderBy(asc(operations.activity_time), asc(operations.id))
      .limit(Number(query.get('limit') || 500)).offset(Number(query.get('offset') || 0));
  };
}
export async function authenticate(read: ReturnType<typeof upstream>) {
  const user = await read('auth/v1/user');
  if (!user?.id) throw new HttpError(401, 'Silakan masuk kembali.');
  return user as { id: string };
}
export async function requireManager(read: ReturnType<typeof upstream>, userId: string) {
  const profiles = await read(`rest/v1/profiles?select=role&id=eq.${encodeURIComponent(userId)}`);
  if (!['admin', 'supervisor'].includes(profiles[0]?.role)) throw new HttpError(403, 'Unduhan hanya untuk admin dan supervisor.');
}
export function monthBounds(month: string, offset: string) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month) || Number(month.slice(0,4)) < 2000 || !/^-?\d+$/.test(offset)) {
    throw new HttpError(400, 'Pilih bulan yang valid.');
  }
  const minutes = Number(offset);
  if (minutes < -840 || minutes > 840) throw new HttpError(400, 'Zona waktu tidak valid.');
  const [year, m] = month.split('-').map(Number);
  return [new Date(Date.UTC(year, m - 1, 1) + minutes * 60000).toISOString(),
    new Date(Date.UTC(year, m, 1) + minutes * 60000).toISOString()];
}
export function csvCell(value: unknown) {
  let text = String(value ?? '');
  if (/^[\s\uFEFF]*[=+@-]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
  return '"' + text.replace(/"/g, '""') + '"';
}
export function errorResponse(error: unknown) {
  return Response.json({ error: error instanceof HttpError ? error.message : 'Layanan sementara tidak tersedia. Silakan coba lagi.' },
    { status: error instanceof HttpError ? error.status : 503, headers: { 'Cache-Control': 'no-store' } });
}

export async function monthlyOperations(read: ReturnType<typeof upstream>, start: string, end: string) {
  const rows = [];
  for (let page = 0; ; page++) {
    const query = new URLSearchParams({ select: '*', deleted_at: 'is.null',
      and: `(activity_time.gte.${start},activity_time.lt.${end})`,
      order: 'activity_time.asc,id.asc', limit: '500', offset: String(page * 500) });
    const batch = await read(`rest/v1/operations?${query}`);
    rows.push(...batch);
    if (batch.length < 500) return rows;
  }
}
