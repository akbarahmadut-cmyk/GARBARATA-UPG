import { randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { asc, eq, sql } from 'drizzle-orm';
import type { User } from '@netlify/identity';
import { database } from '../db/index.js';
import { staffAccounts } from '../db/schema.js';

const scryptAsync = promisify(scrypt) as (pin: string, salt: Buffer, length: number) => Promise<Buffer>;
export const STAFF_ROLES = ['operator', 'supervisor'];
export const MAX_FAILED_ATTEMPTS = 5;
export const LOCK_MINUTES = 15;
export type StaffAccount = typeof staffAccounts.$inferSelect;

export function normalizeLoginId(value: unknown) {
  return typeof value === 'string' ? value.trim().toUpperCase() : '';
}
export function validLoginId(loginId: string) { return /^[A-Z0-9._-]{3,32}$/.test(loginId); }
export function validPin(pin: unknown): pin is string { return typeof pin === 'string' && /^\d{6,12}$/.test(pin); }

export async function hashPin(pin: string) {
  const salt = randomBytes(16);
  const key = await scryptAsync(pin, salt, 32);
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}
export async function verifyPin(pin: string, stored: string) {
  const [scheme, salt, key] = stored.split('$');
  if (scheme !== 'scrypt' || !salt || !key) return false;
  const expected = Buffer.from(key, 'base64');
  const actual = await scryptAsync(pin, Buffer.from(salt, 'base64'), expected.length);
  return timingSafeEqual(actual, expected);
}

// Staff accounts are exposed in the same shape as Identity users so role checks stay in one place.
export function staffUser(account: StaffAccount): User {
  return { id: account.id, name: account.fullName, userMetadata: { full_name: account.fullName, login_id: account.loginId },
    appMetadata: { roles: [account.role], staff: true, active: account.active } } as User;
}
export function isStaffUser(user: User) { return user.appMetadata?.staff === true; }

export const staffStore = {
  async byId(id: string) {
    if (!/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(id)) return null;
    const rows = await database().select().from(staffAccounts).where(eq(staffAccounts.id, id)).limit(1);
    return rows[0] ?? null;
  },
  async byLoginId(loginId: string) {
    const rows = await database().select().from(staffAccounts).where(eq(staffAccounts.loginId, loginId)).limit(1);
    return rows[0] ?? null;
  },
  async all() {
    return database().select().from(staffAccounts).orderBy(asc(staffAccounts.fullName));
  },
  async create(values: { loginId: string; fullName: string; role: string; pinHash: string }) {
    const rows = await database().insert(staffAccounts).values(values).onConflictDoNothing({ target: staffAccounts.loginId }).returning();
    return rows[0] ?? null;
  },
  async update(id: string, values: Partial<Pick<StaffAccount, 'fullName' | 'pinHash' | 'active' | 'role'>>) {
    const reset = values.pinHash || values.active ? { failedAttempts: 0, lockedUntil: null } : {};
    const rows = await database().update(staffAccounts).set({ ...values, ...reset }).where(eq(staffAccounts.id, id)).returning();
    return rows[0] ?? null;
  },
  async recordFailure(id: string, now: Date) {
    await database().update(staffAccounts).set({
      failedAttempts: sql`${staffAccounts.failedAttempts} + 1`,
      lockedUntil: sql`CASE WHEN ${staffAccounts.failedAttempts} + 1 >= ${MAX_FAILED_ATTEMPTS} THEN ${new Date(now.getTime() + LOCK_MINUTES * 60000).toISOString()}::timestamptz ELSE NULL END`,
    }).where(eq(staffAccounts.id, id));
  },
  async recordSuccess(id: string) {
    await database().update(staffAccounts).set({ failedAttempts: 0, lockedUntil: null }).where(eq(staffAccounts.id, id));
  },
};

export class StaffLoginError extends Error {}
// A dummy hash keeps response timing similar for unknown login IDs.
let dummyHash: Promise<string> | null = null;
export async function staffLogin(loginIdInput: unknown, pin: unknown, now = new Date()) {
  const loginId = normalizeLoginId(loginIdInput);
  const invalid = 'ID atau PIN salah.';
  if (!validLoginId(loginId) || typeof pin !== 'string' || !pin) throw new StaffLoginError(invalid);
  const account = await staffStore.byLoginId(loginId);
  if (!account) { await verifyPin(pin, await (dummyHash ??= hashPin('000000'))); throw new StaffLoginError(invalid); }
  if (account.lockedUntil && account.lockedUntil > now) {
    throw new StaffLoginError(`Terlalu banyak percobaan. Coba lagi dalam ${LOCK_MINUTES} menit atau hubungi admin.`);
  }
  const ok = await verifyPin(pin, account.pinHash);
  if (!ok) { await staffStore.recordFailure(account.id, now); throw new StaffLoginError(invalid); }
  if (!account.active) throw new StaffLoginError('Akun dinonaktifkan. Hubungi admin.');
  await staffStore.recordSuccess(account.id);
  return account;
}
