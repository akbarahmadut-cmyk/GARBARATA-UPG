import { randomBytes, createHash } from 'node:crypto';
import type { Context } from '@netlify/functions';
import { and, eq, gt, lte } from 'drizzle-orm';
import { database } from '../db/index.js';
import { userSessions } from '../db/schema.js';

export const SESSION_SECONDS = 5 * 60 * 60;
const COOKIE = '__Host-ops_session';
function cookies() {
  return (globalThis as typeof globalThis & { Netlify?: { context?: Context } }).Netlify?.context?.cookies;
}
function hash(value: string) { return createHash('sha256').update(value).digest('hex'); }
export const sessionStore = {
  async userId(idHash: string, now: Date) {
    const rows = await database().select({ userId: userSessions.userId }).from(userSessions)
      .where(and(eq(userSessions.idHash, idHash), gt(userSessions.expiresAt, now))).limit(1);
    return rows[0]?.userId ?? null;
  },
  async create(idHash: string, userId: string, expiresAt: Date) {
    await database().delete(userSessions).where(lte(userSessions.expiresAt, new Date()));
    await database().insert(userSessions).values({ idHash, userId, expiresAt });
  },
  async valid(idHash: string, userId: string, now: Date) {
    const rows = await database().select({ id: userSessions.idHash }).from(userSessions)
      .where(and(eq(userSessions.idHash, idHash), eq(userSessions.userId, userId), gt(userSessions.expiresAt, now))).limit(1);
    return rows.length > 0;
  },
  async removeForUser(userId: string) {
    await database().delete(userSessions).where(eq(userSessions.userId, userId));
  },
  async remove(idHash: string) {
    await database().delete(userSessions).where(eq(userSessions.idHash, idHash));
  },
};
export async function sessionUserId() {
  const id = cookies()?.get(COOKIE);
  if (!id || !/^[a-f0-9]{64}$/.test(id)) return null;
  return sessionStore.userId(hash(id), new Date());
}
export async function startSession(userId: string) {
  const jar = cookies();
  if (!jar) throw new Error('Session runtime unavailable');
  await endSession();
  const id = randomBytes(32).toString('hex');
  await sessionStore.create(hash(id), userId, new Date(Date.now() + SESSION_SECONDS * 1000));
  jar.set({ name: COOKIE, value: id, httpOnly: true, secure: true, sameSite: 'Lax', path: '/', maxAge: SESSION_SECONDS });
}
export async function validSession(userId: string) {
  const id = cookies()?.get(COOKIE);
  return !!id && /^[a-f0-9]{64}$/.test(id) && await sessionStore.valid(hash(id), userId, new Date());
}
export async function endSession() {
  const jar = cookies();
  const id = jar?.get(COOKIE);
  if (id) await sessionStore.remove(hash(id));
  jar?.delete(COOKIE);
}
