-- Inspeksi metadata saja. Bukan migration dan belum dijalankan.
-- Kanal yang dipilih: administrator menjalankan melalui Supabase SQL Editor.
-- Tandai seluruh hasil yang dibagikan sebagai "ekspor administrator".
-- Simpan SETIAP result set (termasuk hasil kosong), bukan hanya hasil terakhir.
-- Untuk menjalankan per bagian, bungkus SELECT dengan BEGIN READ ONLY,
-- SET LOCAL timeout seperti di bawah, lalu ROLLBACK.
-- Jangan membuat role atau mengubah grant pada tahap ini.
-- Tidak membaca baris aplikasi, auth.users, password, atau token.
BEGIN READ ONLY;
SET LOCAL statement_timeout = '15s';
SET LOCAL lock_timeout = '2s';

-- 1. Keberadaan tabel dan RLS; hasil kosong berarti tidak terlihat/tidak ada.
SELECT n.nspname AS schema_name, c.relname AS table_name,
       c.relkind, c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS rls_forced,
       pg_get_userbyid(c.relowner) AS owner
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE (n.nspname = 'public' AND c.relname IN ('profiles','operations','audit_logs'))
   OR (n.nspname = 'auth' AND c.relname = 'users')
ORDER BY 1,2;

-- 2. Seluruh kolom, termasuk tipe enum/domain, nullability, dan generated.
SELECT n.nspname AS schema_name, c.relname AS table_name,
       a.attnum AS ordinal_position, a.attname AS column_name,
       format_type(a.atttypid,a.atttypmod) AS data_type,
       a.attnotnull AS not_null, a.attidentity AS identity_kind,
       a.attgenerated AS generated_kind
FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public' AND c.relname IN ('profiles','operations','audit_logs')
  AND a.attnum > 0 AND NOT a.attisdropped
ORDER BY 1,2,3;

-- 3. Primary/foreign/unique/check constraints, termasuk FK masuk/keluar.
SELECT n.nspname AS schema_name, c.relname AS table_name,
       k.conname, k.contype, k.convalidated,
       pg_get_constraintdef(k.oid,true) AS definition
FROM pg_constraint k JOIN pg_class c ON c.oid = k.conrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE (n.nspname = 'public' AND c.relname IN ('profiles','operations','audit_logs'))
   OR k.confrelid IN (
       SELECT t.oid FROM pg_class t JOIN pg_namespace s ON s.oid=t.relnamespace
       WHERE s.nspname='public' AND t.relname IN ('profiles','operations','audit_logs')
   )
ORDER BY 1,2,3;

-- 4. Index beserta validitas dan readiness.
SELECT n.nspname AS schema_name, t.relname AS table_name,
       i.relname AS index_name, x.indisvalid, x.indisready,
       pg_get_indexdef(i.oid) AS definition
FROM pg_index x JOIN pg_class t ON t.oid=x.indrelid
JOIN pg_class i ON i.oid=x.indexrelid
JOIN pg_namespace n ON n.oid=t.relnamespace
WHERE n.nspname='public' AND t.relname IN ('profiles','operations','audit_logs')
ORDER BY 1,2,3;

-- 5. Semua policy; periksa bersama status RLS, grants, serta policy lain
-- yang permissive (OR) dan restrictive (AND), bukan satu policy terpisah.
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname='public' AND tablename IN ('profiles','operations','audit_logs')
ORDER BY tablename,policyname;

-- 6. Grants tabel/kolom. information_schema mengikuti visibilitas role inspeksi;
-- hasil kosong bukan bukti tidak ada grant.
SELECT table_schema,table_name,grantor,grantee,privilege_type,is_grantable
FROM information_schema.table_privileges
WHERE table_schema='public' AND table_name IN ('profiles','operations','audit_logs')
ORDER BY table_name,grantee,privilege_type;
SELECT table_schema,table_name,column_name,grantee,privilege_type
FROM information_schema.column_privileges
WHERE table_schema='public' AND table_name IN ('profiles','operations','audit_logs')
ORDER BY table_name,column_name,grantee,privilege_type;

-- 7. Trigger dan fungsi terkait (metadata saja, tanpa menjalankan fungsi).
SELECT n.nspname AS schema_name,c.relname AS table_name,t.tgname,
       t.tgenabled, f.oid::regprocedure::text AS function_signature,
       f.prosecdef AS security_definer, pg_get_userbyid(f.proowner) AS function_owner
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
JOIN pg_namespace n ON n.oid=c.relnamespace
JOIN pg_proc f ON f.oid=t.tgfoid
WHERE n.nspname='public' AND c.relname IN ('profiles','operations','audit_logs')
  AND NOT t.tgisinternal
ORDER BY 1,2,3;

-- 8. Role yang bisa melewati RLS dan hubungan role API yang relevan.
SELECT rolname,rolsuper,rolbypassrls,rolinherit
FROM pg_roles WHERE rolname IN ('anon','authenticated','service_role',current_user);
SELECT parent.rolname AS granted_role,member.rolname AS member_role
FROM pg_auth_members m JOIN pg_roles parent ON parent.oid=m.roleid
JOIN pg_roles member ON member.oid=m.member
WHERE member.rolname IN ('anon','authenticated','service_role',current_user);
ROLLBACK;
