# Verifikasi integrasi Supabase — 11 November 2026

Status: **masih memiliki hambatan; belum siap implementasi**. Audit kode statis telah dilakukan kembali. Pengguna telah memilih **ekspor metadata tersanitasi oleh administrator** melalui Supabase SQL Editor sebagai kanal bukti; koneksi langsung tidak diperlukan. Hasil ekspor belum disertakan dalam pesan atau berkas yang tersedia. Tidak ada upaya login, request database produksi, perubahan akun/data/konfigurasi, migration, build, atau deployment.

Keputusan pengguna yang sudah final: **supervisor boleh melakukan soft delete pada seluruh riwayat**, tanpa batas shift. Data fisik dan audit dipertahankan. Keputusan ini merupakan spesifikasi pengujian dan rancangan, bukan perubahan policy yang telah diterapkan.

Tahap dokumentasi ini diselesaikan dengan bukti yang tersedia setelah permintaan hasil ekspor dilewati pengguna. Tidak diajukan permintaan ulang. Inspeksi database aktual dan validasi Auth tetap belum selesai; tidak ada asumsi bahwa jawaban yang dilewati berarti skema cocok atau pengujian berhasil.

## Ringkasan hasil tahap ini

- Selesai: pemetaan statis jalur query aktif, temuan akses catatan lintas shift dan cakupan direktori profile, rancangan uji JWT per role, kebijakan soft delete supervisor seluruh riwayat, checklist Auth enam jam, dan query inspeksi metadata read-only.
- Belum dapat dipastikan: seluruh kolom/tipe/PK/FK/index/RLS/policy aktual ketiga tabel, relasi auth.users, tempat penyimpanan catatan, serta konfigurasi Auth proyek. Daftar bukti spesifik yang belum tersedia tercantum di bawah.
- Rancangan migration tetap bersyarat; SQL perubahan skema tidak dibuat karena berisiko mengasumsikan kolom, menduplikasi objek, atau bertentangan dengan policy existing. Berkas inspeksi SQL bukan migration.
- Tidak ada pengujian integrasi Supabase yang dijalankan. Pada kelanjutan dokumentasi ini tidak dijalankan tes aplikasi ulang karena tidak ada perubahan kode runtime; hasil tes implementasi Netlify tidak menjadi bukti keberhasilan Supabase.
- Seluruh perubahan tahap ini hanya pada dokumen dan komentar berkas inspeksi. Database produksi, data, akun, applied migration, kode aplikasi, dan konfigurasi deployment tidak diubah.

## Struktur aktual dan bukti yang belum tersedia

| Objek | Kolom/tipe | PK/FK dan auth.users | Index | RLS/policy/grant |
| --- | --- | --- | --- | --- |
| public.profiles | Belum terverifikasi | Belum terverifikasi | Belum terverifikasi | Belum terverifikasi |
| public.operations | Belum terverifikasi | Belum terverifikasi | Belum terverifikasi | Belum terverifikasi |
| public.audit_logs | Belum terverifikasi | Belum terverifikasi | Belum terverifikasi | Belum terverifikasi |

Nama tabel berasal dari permintaan, bukan hasil pemeriksaan database. Kolom `user_id` dan relasi yang diminta belum boleh dianggap sudah ada. Tidak ada query Supabase yang dijalankan, sehingga belum ada kegagalan query Supabase yang teramati.

`supabase-inspection.sql` menyediakan inspeksi katalog dalam transaksi READ ONLY dengan timeout, tanpa membaca baris pengguna atau aktivitas. Berkas ini **bukan migration** dan belum dijalankan oleh sesi ini. Administrator menjalankannya melalui SQL Editor sesuai kanal yang dipilih. Seluruh bukti yang diterima akan ditandai **ekspor administrator**, bukan inspeksi langsung atau hasil uji JWT. Tidak diminta kredensial maupun koneksi langsung.

### Daftar metadata yang masih belum diterima

Sertakan waktu ekspor dan label lingkungan (produksi/staging, tanpa connection string), agar hasil dapat dinilai dalam konteks yang tepat. Untuk setiap kelompok berikut, sertakan semua result set, atau keterangan eksplisit “0 baris”, “izin ditolak”, atau pesan error yang sudah disanitasi. Keberhasilan eksekusi atau hasil ROLLBACK saja bukan bukti struktur.

1. Bagian 1 SQL: keberadaan tiga tabel, owner, RLS enabled/forced dan keberadaan auth.users.
2. Bagian 2: seluruh kolom/tipe/nullability/identity/generated ketiga tabel.
3. Bagian 3: definisi seluruh PK/FK/unique/check termasuk FK masuk/keluar dan status validasi.
4. Bagian 4: seluruh index, definisi, validitas dan readiness.
5. Bagian 5: seluruh policy, role, command, permissive/restrictive, USING dan WITH CHECK.
6. Bagian 6: kedua result set grants tabel dan grants kolom.
7. Bagian 7: trigger aktif/nonaktif dan metadata fungsi terkait, termasuk SECURITY DEFINER.
8. Bagian 8: kedua result set atribut role API/BYPASSRLS dan keanggotaan role.
9. Konfigurasi Auth nonrahasia dari dashboard: email/password aktif/tidak, kebijakan signup/konfirmasi, JWT lifetime, refresh rotation/reuse interval, time-box sesi/inactivity timeout dan dukungan paket, serta konfigurasi redirect/recovery. SQL katalog tidak menghasilkan konfigurasi Auth ini. Cukup status/durasi dan ringkasan aturan; jangan mengirim URL bertoken atau pengaturan SMTP yang berisi kredensial.

SQL Editor dapat menampilkan hanya result set terakhir. Simpan setiap result set secara terpisah bila perlu. Jika menjalankan per bagian, bungkus SELECT bagian tersebut dengan BEGIN READ ONLY, pengaturan timeout dari awal berkas, dan ROLLBACK; bila terjadi error, akhiri transaksi yang gagal dengan ROLLBACK sebelum melanjutkan. Jangan menambahkan SQL penulisan atau menjalankan uji mutation di produksi. Definisi helper/default/grants EXECUTE dan view/RPC spesifik mungkin diperlukan sebagai tindak lanjut setelah nama objek diketahui; saat ini belum ada bukti untuk menyimpulkan objek tersebut ada atau tidak ada.

Role inspeksi perlu memiliki visibilitas metadata yang memadai. Hasil information_schema yang kosong dapat disebabkan izin terbatas. Catalog query tidak memanggil fungsi aplikasi. Tinjau ekspor sebelum membagikannya: ekspresi constraint/policy/index dapat mengandung literal internal. Jangan menyertakan token, password/hash, connection string, data pribadi, atau nilai environment variable. Definisi helper RLS, grants EXECUTE, search_path fungsi SECURITY DEFINER, view/RPC yang mengekspos tabel, serta default kolom juga perlu ditinjau secara aman setelah objek sebenarnya diketahui. RLS enabled saja tidak membuktikan aman: owner, BYPASSRLS, grants, dan seluruh policy harus dinilai bersama.

## Pemetaan seluruh jalur query aplikasi

| Jalur/file | Bentuk sumber yang dipakai kode saat ini | Verifikasi tujuan / risiko bersyarat |
| --- | --- | --- |
| db/schema.ts; operations GET | `operations.id` uuid PK; `flight_number`, `aircraft_registration`, `parking_stand`, `activity` text NOT NULL; `activity_time` timestamptz NOT NULL; `operator_id` uuid NOT NULL; `deleted_at` timestamptz nullable; `deleted_by` uuid nullable. Filter soft delete, rentang shift, hitung per aktivitas, urut waktu/id DESC, pagination 10 baris. | Cocokkan seluruh kolom/tipe/default/check; bila tujuan hanya memiliki `user_id`, query `operator_id` tidak dapat langsung digunakan. Statistik dan pagination harus dihitung setelah RLS/filter yang sama. |
| operations POST | Menulis field di atas dengan `flight_number=''`, pemilik dari sesi server, returning id. | Periksa apakah flight_number wajib/tersedia dan nilai enum activity benar-benar `Docking`/`Undocking`. Validasi pemilik via `auth.uid()`, waktu, registrasi, dan stand di database. Jangan mengganti ID akun tanpa pemetaan. |
| operations DELETE | Sebenarnya UPDATE `deleted_at`, `deleted_by`, bukan DELETE fisik. | Uji policy UPDATE beserta pembatasan kolom; policy DELETE saja tidak mengamankan soft delete. Pastikan actor dan waktu penghapusan tidak dapat dipalsukan. |
| operations GET leaderboard | GROUP BY operator_id pada shift; daftar operator dari Identity. | Perlu profile yang dapat dibaca sesuai kebutuhan leaderboard, tanpa membuka seluruh email/direktori kepada operator. |
| server/operations.ts upstream | Path `auth/v1/user` dan `rest/v1/profiles` dilayani adapter lokal Identity, bukan jaringan Supabase. Profile publik berbentuk id/email/full_name/role. | Tidak ada query nyata terhadap public.profiles. Adapter mengabaikan sebagian select/filter profile dan mengembalikan seluruh direktori. Tidak dapat dipindahkan apa adanya. Role saat ini dari appMetadata.roles, bukan profiles.role. |
| operation-notes POST, mode baca | Membaca operation id/operator_id yang belum dihapus, lalu `operation_notes` dengan operation_id/author_id uuid, note text, created_at timestamptz. | Penyimpanan catatan di tujuan belum diketahui. Jangan membuat tabel duplikat atau menghilangkan catatan bila tiga tabel tujuan belum menampungnya. |
| operation-notes POST, mode simpan | Memastikan pemilik kegiatan, lalu UPSERT berdasarkan operation_id. | Periksa lokasi catatan, constraint unik, FK, kepemilikan dan pembatasan shift. |
| monthly-export GET | Seluruh kegiatan aktif dalam rentang bulan; urut waktu/id ASC, batch 500; join nama/email operator serta catatan. | Verifikasi field tujuan, pembacaan lintas halaman, role pengunduh, waktu lokal, dan izin field profile. Ekspor tidak boleh memakai key istimewa sebagai pengganti pemeriksaan role/RLS. |
| accounts GET/POST/PATCH | Identity Admin API: daftar, buat akun tiga role, ubah nama operator/supervisor. | Belum ada implementasi Supabase; pengelolaan role dan seluruh akun belum lengkap. Profile bukan pengganti otomatis auth.users. |
| session GET/POST; server/sessions.ts | Login/logout/invite/recovery Identity; hash sesi di user_sessions(id_hash text PK, user_id uuid, expires_at timestamptz), batas absolut 5 jam. | Belum ada sesi/refresh Supabase. Tabel sesi lama bukan bukti konfigurasi Auth Supabase. |
| index.html | Seluruh request diarahkan ke /.netlify/functions; rendering dan payload masih memakai operator_id. | Penggantian backend memerlukan adapter dan pemetaan field, nama/email, error, callback, pagination dan retry tanpa mengubah desain. |
| audit_logs | Tidak ada query aktif. | Struktur, trigger, pembuat actor, dan retensi belum diketahui; belum ada bukti pencatatan audit. |

### Masalah kode yang terkonfirmasi

1. **Batas shift catatan tidak konsisten.** `operation-notes.mts` menggunakan `upstream()` yang hanya menyaring ID dan soft delete tanpa `operatorShift`. Operator yang mengetahui ID kegiatan lama dapat meminta catatannya; kegiatan miliknya sendiri juga dapat diperbarui catatannya di luar shift. Ini hasil inspeksi kode, bukan eksploitasi produksi. Masukkan kasus ini dalam uji regresi dan RLS tujuan.
2. **Direktori profil terlalu luas untuk ditransfer langsung.** Endpoint operations mengirim semua `publicUser`, termasuk email dan role, kepada seluruh akun ber-role. Perlu menetapkan data minimum bagi operator dan memastikan anon tidak dapat membacanya.
3. **Sesi belum sesuai target.** Batas saat ini lima jam dan menggunakan mekanisme Netlify, belum Supabase.
4. **Integrasi belum aktif.** SDK browser lokal tersedia tetapi belum digunakan; dependensi proyek tetap Identity/Database/Drizzle. RLS dan audit Supabase belum dapat dinilai dari repo.
5. **Filter tanggal/pencarian dan XLSX belum ditemukan.** Tersedia pagination riwayat dan CSV bulanan. Kebutuhan tersebut harus masuk kriteria implementasi, tanpa dianggap fitur yang sudah diuji.

## Inspeksi Auth yang diperlukan

Seluruh status Supabase di bawah **belum terverifikasi**. Minta tampilan konfigurasi nonrahasia/read-only dari dashboard atau API konfigurasi dengan penyaringan sebelum output; jangan menyalin respons mentah yang dapat mengandung rahasia.

| Area | Bukti yang perlu diperiksa | Kriteria penerimaan |
| --- | --- | --- |
| Email/password | Provider email, kebijakan signup/undangan, konfirmasi email dan recovery, konfigurasi SMTP tanpa kredensial | Login akun existing berfungsi; tidak membuat/mengubah akun pada tahap inspeksi |
| Refresh | Rotation, reuse interval, JWT lifetime, time-box sesi dan ketersediaan pada paket proyek | Refresh sah diterima sebelum batas; refresh tidak mereset waktu awal sesi |
| Pemulihan sesi | Konfigurasi SDK, persistSession/autoRefreshToken, event Auth, validasi identitas di server | Reload/tab baru mempertahankan identitas; state browser bukan sumber otorisasi |
| Enam jam | Batas sesi absolut 21.600 detik dan sumber waktu awal sesi terverifikasi | Semua jalur database/RPC/administratif menolak pada/setelah batas walaupun access token masih valid |
| Logout | Scope signOut, pencabutan refresh token, perilaku JWT yang sudah diterbitkan | Logout membersihkan UI; tidak bisa refresh ulang. Jika akses harus langsung terputus, perlu pemeriksaan sesi/revokasi di server/database karena JWT dapat berlaku hingga expiry |
| Kedaluwarsa | Validasi JWT signature/issuer/audience/expiry dan sesi autentikasi pada jalur tepercaya | Token expired, invalid, sesi dicabut, dan sesi lebih dari enam jam ditolak sesuai kebijakan |
| Redirect | Site URL dan allowlist callback produksi/staging | Recovery dan callback kembali ke domain yang disetujui, tanpa redirect terbuka |

JWT lifetime enam jam atau timer frontend saja tidak cukup. Batas time-box Supabase dapat diperiksa saat refresh; access token yang sudah diterbitkan perlu gerbang database/server tambahan untuk batas enam jam yang ketat. Rancangan harus memverifikasi sumber session_id dan waktu awal autentikasi sebenarnya; `iat` access token yang di-refresh tidak boleh menjadi waktu mulai baru. Jangan memberi pengguna akses baca bebas ke tabel internal auth.sessions. Helper bila diperlukan harus memiliki scope minimum, search_path aman, dan grants terbatas.

## Rancangan pengujian RLS dan integrasi

**Belum dijalankan.** Semua pengujian yang menulis, menghapus, login/refresh/logout atau mengubah akun hanya pada staging terisolasi dengan fixture sintetis setelah persetujuan rancangan. Produksi pada tahap ini hanya metadata read-only; bahkan write test yang di-ROLLBACK tidak dijalankan di produksi karena trigger/efek samping dapat terjadi. Tidak membuat akun test dalam tahap ini.

Gunakan JWT asli admin, supervisor, operator A, operator B pada request Supabase masing-masing dan publishable/anon key yang sesuai. JWT hanya ditangani kanal rahasia runtime; redaksi Authorization, cookie, body autentikasi, email, dan refresh token dari output. Jangan memakai service_role, koneksi owner, atau BYPASSRLS untuk menilai RLS. SQL SET ROLE saja bukan pengganti uji JWT end-to-end. Anon diuji tanpa sesi pengguna; invalid/expired JWT diuji terpisah.

Fixture staging: tiga role dan dua operator, kegiatan pada shift aktif/sebelum/sesudah shift, kegiatan terhapus, profile tanpa role/role tak dikenal, serta audit fixture. Tidak mengandalkan data pengguna asli. Periksa status/error **dan isi/baris terdampak**: RLS dapat mengembalikan 200 dengan nol baris untuk UPDATE/DELETE terlarang. Konfirmasikan keadaan sebelum/sesudah melalui principal pengamat staging yang berwenang, tanpa service_role sebagai principal yang diuji.

| Uji | Aksi langsung dengan JWT terkait | Hasil wajib |
| --- | --- | --- |
| R01 | Anon SELECT ketiga tabel, termasuk filter ID dan permintaan jumlah baris | Tidak ada data pribadi atau kebocoran jumlah; tolak mutation/RPC juga |
| R02 | Operator UPDATE profiles.role dirinya sendiri, UPSERT profile, ubah metadata role | Role efektif tetap; tidak naik menjadi admin/supervisor |
| R03 | Operator DELETE operations dan PATCH deleted_at/deleted_by | Tidak ada kegiatan terhapus atau berubah |
| R04 | Admin/supervisor soft delete fixture pada shift aktif dan riwayat shift/bulan sebelumnya | Berhasil untuk seluruh riwayat, actor/waktu benar dan audit tercatat; baris fisik tetap ada. DELETE fisik ditolak pada jalur aplikasi; pengulangan soft delete tidak mengganti actor/waktu penghapusan pertama atau menggandakan audit perubahan |
| R05 | Supervisor mencoba mengubah/menghapus akun atau profile admin | Ditolak; jalur administratif dan RPC juga diuji |
| R06 | Operator A insert kegiatan atas ID B, ubah user_id/pemilik/ID setelah insert | Ditolak; valid insert atas dirinya berhasil |
| R07 | Operator baca riwayat, count, join, catatan dan RPC di kedua sisi batas shift WITA | Hanya cakupan shift yang disetujui, tanpa catatan atau statistik dari luar cakupan |
| R08 | Admin/supervisor baca seluruh riwayat dan CSV; operator panggil jalur ekspor langsung | Manager berhasil; ekspor operator ditolak. Jangan mengklaim kerahasiaan data ekspor jika operator memang diizinkan membaca data yang sama |
| R09 | Pengguna biasa INSERT audit dengan actor palsu, UPDATE/DELETE audit, akses RPC audit | Semua manipulasi ditolak; audit sah hanya berasal dari jalur tepercaya |
| R10 | JWT salah signature/issuer/audience, expired, akun tanpa role | Tidak memperoleh data atau menjalankan aksi; hindari fallback anonim yang membocorkan data |
| R11 | Role diubah/dicabut pada fixture, token lama dipakai lagi | Hak mengikuti kebijakan role terkini; cache/claim lama tidak memberi hak berlebihan |
| R12 | Ulang R01–R11 lewat view, relasi join, bulk/upsert, RPC, dan endpoint administratif yang ditemukan | Tidak ada jalur melewati kebijakan; inspeksi seluruh policy permissive/restrictive |
| I01 | Login ketiga role, reload/tab baru | Nama/email identitas benar, role sesuai, tidak ada rahasia di browser/log |
| I02 | Docking/undocking, retry simpan catatan, baca kembali | Tidak ada duplikasi; registrasi/stand/waktu/pemilik/catatan benar dan persisten |
| I03 | Refresh pada sebelum enam jam, tepat enam jam, sesudah enam jam; gunakan JWT yang belum expired setelah batas | Sesi tidak meluncur melewati enam jam; semua jalur sensitif menolak setelah batas |
| I04 | Logout lalu pakai refresh token/JWT lama dan login ulang | Refresh lama ditolak; perilaku JWT sesuai gerbang revokasi; login baru membentuk sesi baru |
| I05 | Recovery/invite pada fixture staging | Callback valid, error aman; tidak mengubah akun produksi |
| I06 | Pagination >500, filter sebelum pagination, pencarian, total, leaderboard dan CSV | Hasil konsisten dengan RLS, shift WITA, rentang bulan, catatan dan pemilik |
| I07 | UI HP/PC, service worker, jaringan gagal dan retry | Desain/fitur tetap; tidak menampilkan data privat dari cache sesi lain |

Hak supervisor sudah diputuskan: soft delete seluruh riwayat. RLS tujuan perlu mengizinkan UPDATE untuk aksi ini secara terkendali, bukan memberikan kebebasan UPDATE semua kolom atau DELETE fisik. Uji tambahan wajib menolak perubahan registrasi, waktu, pemilik, atau role yang disisipkan ke request soft delete, serta menolak pengosongan deleted_at untuk memulihkan data tanpa kebijakan pemulihan yang disetujui. Akses baca audit, daftar nama/email operator, dan hak admin mengubah akun admin lain tetap perlu dicocokkan dengan kebijakan aktual sebelum policy final.

## Rancangan migration — bersyarat, belum SQL executable

Tidak dibuat CREATE/ALTER/DROP, policy executable, atau perubahan data karena skema aktual belum diketahui. Berkas SQL pendamping hanya SELECT katalog dalam transaksi read-only. Setelah bukti diperoleh, rancangan migration harus mencakup:

1. Preflight keberadaan tabel/kolom, tipe, PK, orphan, duplikasi, dependensi dan backup teruji. Jika struktur tidak cocok, hentikan bagian terkait dan laporkan selisih sebelum query aplikasi berubah.
2. Pertahankan tabel existing, buat pemetaan Identity ID → Auth ID → profile ID yang ditinjau. Jangan rename operator_id, overwrite user_id atau menautkan berdasarkan email secara otomatis.
3. Jika belum tersedia, usulkan FK profiles.id → auth.users.id dan operations.user_id → profiles.id. Tentukan ON DELETE tanpa menghapus riwayat; penambahan/validasi constraint harus memperhitungkan orphan dan lock. Jangan menerapkan CASCADE secara asumtif.
4. Usulkan constraints input dan index berdasarkan query/filter/EXPLAIN yang diperiksa secara aman; hindari index duplikat. Tentukan tempat catatan berdasarkan struktur existing.
5. Rancang grants tabel/kolom, policies SELECT/INSERT/UPDATE/DELETE dengan USING/WITH CHECK, helper role/sesi yang tidak rekursif, dan proteksi role/owner/soft-delete. Policy baru harus diperiksa bersama seluruh policy existing, karena policy permissive lama dapat memperlebar akses.
6. Sesuaikan trigger audit dengan kolom actual; batasi direct write serta hak update/delete pengguna biasa. Catat perubahan akun melalui jalur administratif; login/logout memerlukan integrasi event Auth tersendiri.
7. Rancang gerbang sesi enam jam untuk seluruh query/RPC/jalur administratif; jangan mengubah tabel internal Auth sembarangan. Ajukan SQL final beserta rencana rollback dan hasil staging untuk persetujuan sebelum produksi.

Ketiga applied migration Netlify tetap utuh dan tidak diubah. Source lama, database, dan akun tetap dipertahankan. Lingkungan saat ini juga membatasi implementasi backend/persistence ke layanan Netlify; inspeksi read-only dapat dilanjutkan bila tersedia kanal aman, tetapi implementasi penuh backend Supabase membutuhkan lingkungan yang mengizinkannya.

## Keputusan kesiapan

**Belum siap memasuki implementasi Supabase.** Kanal bukti dan kebijakan hapus supervisor telah diputuskan. Hambatan berikutnya adalah hasil ekspor administrator yang belum diterima, sehingga skema/policy/config Auth aktual, kecocokan kolom/relasi, dan lokasi catatan belum dapat dinilai. Tidak ada query Supabase yang diklaim berhasil atau gagal tanpa bukti. Setelah ekspor diterima, setiap temuan diberi sumber “ekspor administrator”, lalu dipetakan menjadi cocok/tidak cocok/belum terbukti beserta rancangan migration spesifik untuk ditinjau. Pengujian integrasi dan perubahan produksi tetap belum diizinkan oleh dokumen ini.
