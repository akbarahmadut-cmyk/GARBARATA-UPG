import { test, mock } from 'node:test';
import assert from 'node:assert/strict';
import accounts from '../netlify/functions/accounts.mjs';
import session from '../netlify/functions/session.mjs';
import { staffStore, hashPin, verifyPin, staffLogin, MAX_FAILED_ATTEMPTS, type StaffAccount } from '../server/staff.js';
import { sessionStore } from '../server/sessions.js';

const ADMIN='00000000-0000-4000-8000-000000000001';
const STAFF='00000000-0000-4000-8000-000000000009';
function request(path:string,method:string,body:unknown){
  return new Request('https://site.example.test/.netlify/functions/'+path,{method,headers:{origin:'https://site.example.test','Content-Type':'application/json'},body:JSON.stringify(body)});
}
async function account(overrides:Partial<StaffAccount>={}):Promise<StaffAccount>{
  return {id:STAFF,loginId:'OPR001',fullName:'Operator Satu',role:'operator',pinHash:await hashPin('123456'),active:true,failedAttempts:0,lockedUntil:null,createdAt:new Date(),...overrides};
}

test('PINs are stored as salted hashes and verified', async()=>{
  const a=await hashPin('123456'),b=await hashPin('123456');
  assert.notEqual(a,b);assert.equal(a.includes('123456'),false);
  assert.equal(await verifyPin('123456',a),true);
  assert.equal(await verifyPin('654321',a),false);
});

test('staff login checks ID and PIN, locks after repeated failures, and rejects inactive accounts', async()=>{
  let stored=await account();
  const byLogin=mock.method(staffStore,'byLoginId',async(id:string)=>id===stored.loginId?stored:null);
  const failure=mock.method(staffStore,'recordFailure',async()=>{stored={...stored,failedAttempts:stored.failedAttempts+1,
    lockedUntil:stored.failedAttempts+1>=MAX_FAILED_ATTEMPTS?new Date(Date.now()+60000):null}});
  const success=mock.method(staffStore,'recordSuccess',async()=>{stored={...stored,failedAttempts:0}});
  try{
    assert.equal((await staffLogin(' opr001 ','123456')).id,STAFF);
    await assert.rejects(staffLogin('NOPE01','123456'),/ID atau PIN salah/);
    for(let i=0;i<MAX_FAILED_ATTEMPTS;i++) await assert.rejects(staffLogin('OPR001','000000'),/ID atau PIN salah/);
    await assert.rejects(staffLogin('OPR001','123456'),/Terlalu banyak percobaan/);
    stored=await account({active:false});
    await assert.rejects(staffLogin('OPR001','123456'),/dinonaktifkan/);
  }finally{byLogin.mock.restore();failure.mock.restore();success.mock.restore();}
});

async function withSession(userId:string, run:(cookies:Map<string,string>)=>Promise<void>){
  const runtime=globalThis as any;const previous=runtime.Netlify;const cookies=new Map<string,string>();
  runtime.Netlify={context:{cookies:{get:(n:string)=>cookies.get(n)??(userId?'a'.repeat(64):undefined),set:(c:any)=>cookies.set(c.name,c.value),delete:(n:string)=>cookies.delete(n)}}};
  const lookup=mock.method(sessionStore,'userId',async()=>userId||null);
  const create=mock.method(sessionStore,'create',async()=>{});
  const remove=mock.method(sessionStore,'remove',async()=>{});
  try{await run(cookies);}finally{runtime.Netlify=previous;lookup.mock.restore();create.mock.restore();remove.mock.restore();}
}

test('operators sign in with ID and PIN without Identity and get their role from the database', async()=>{
  const stored=await account();
  const byLogin=mock.method(staffStore,'byLoginId',async()=>stored);
  const byId=mock.method(staffStore,'byId',async()=>stored);
  const success=mock.method(staffStore,'recordSuccess',async()=>{});
  const original=globalThis.fetch;let identityCalls=0;
  globalThis.fetch=async()=>{identityCalls++;return Response.json({})};
  try{
    await withSession('',async cookies=>{
      const res=await session(request('session','POST',{action:'staff-login',login_id:'opr001',pin:'123456'}));
      assert.equal(res.status,200);assert.equal(cookies.has('__Host-ops_session'),true);
    });
    await withSession(STAFF,async()=>{
      const profile=await (await session(new Request('https://site.example.test/.netlify/functions/session'))).json();
      assert.equal(profile.role,'operator');assert.equal(profile.login_id,'OPR001');assert.equal(profile.full_name,'Operator Satu');
      assert.equal((await accounts(new Request('https://site.example.test/accounts'))).status,403);
    });
    assert.equal(identityCalls,0);
  }finally{globalThis.fetch=original;byLogin.mock.restore();byId.mock.restore();success.mock.restore();}
});

test('admin creates operators and supervisors with ID and PIN, and resetting a PIN ends their sessions', async()=>{
  const runtime=globalThis as any;const previous=runtime.netlifyIdentityContext;
  runtime.netlifyIdentityContext={url:'https://identity.example.test',token:'test-runtime-token'};
  const original=globalThis.fetch;const identityWrites:string[]=[];
  globalThis.fetch=async(input,options)=>{
    if(options?.method==='POST'||options?.method==='PUT') identityWrites.push(String(input));
    return Response.json({id:ADMIN,app_metadata:{roles:['admin']}});
  };
  const existing=await account();
  const byId=mock.method(staffStore,'byId',async(id:string)=>id===STAFF?existing:null);
  const created:any[]=[];
  const create=mock.method(staffStore,'create',async(values:any)=>{
    if(values.loginId==='TAKEN1') return null;
    created.push(values);return {...existing,...values};
  });
  const update=mock.method(staffStore,'update',async(_id:string,values:any)=>({...existing,...values}));
  const revoke=mock.method(sessionStore,'removeForUser',async()=>{});
  try{
    await withSession(ADMIN,async()=>{
      for(const role of ['operator','supervisor']){
        const res=await accounts(request('accounts','POST',{full_name:'Petugas',login_id:'spv-01',pin:'246810',role}));
        assert.equal(res.status,201);
        const body=await res.json();assert.equal(body.login_id,'SPV-01');assert.equal(body.role,role);assert.equal(body.pin,undefined);
      }
      assert.equal(created[0].pinHash.includes('246810'),false);
      assert.equal((await accounts(request('accounts','POST',{full_name:'Petugas',login_id:'TAKEN1',pin:'246810',role:'operator'}))).status,409);
      assert.equal((await accounts(request('accounts','POST',{full_name:'Petugas',login_id:'X',pin:'246810',role:'operator'}))).status,400);
      assert.equal((await accounts(request('accounts','POST',{full_name:'Petugas',login_id:'OPR002',pin:'12ab',role:'operator'}))).status,400);
      assert.deepEqual(identityWrites,[]);
      const res=await accounts(request('accounts','PATCH',{id:STAFF,full_name:'Nama Baru',pin:'135791',role:'operator',active:true}));
      assert.equal(res.status,200);assert.equal((await res.json()).full_name,'Nama Baru');
      assert.equal(revoke.mock.callCount(),1);
      await accounts(request('accounts','PATCH',{id:STAFF,full_name:'Nama Baru',pin:'',role:'operator',active:false}));
      assert.equal(revoke.mock.callCount(),2);
    });
  }finally{globalThis.fetch=original;runtime.netlifyIdentityContext=previous;byId.mock.restore();create.mock.restore();update.mock.restore();revoke.mock.restore();}
});
