import { test, mock } from 'node:test';
import assert from 'node:assert/strict';
import accounts from '../netlify/functions/accounts.mjs';
import operations from '../netlify/functions/operations.mjs';
import monthlyExport from '../netlify/functions/monthly-export.mjs';
import { userRole, publicUser } from '../server/operations.js';

import { sessionStore } from '../server/sessions.js';
import { staffStore } from '../server/staff.js';

// Identity runtime and upstream responses are simulated; no real accounts are created.
async function identityHarness(role: string, run: (calls: {url:string;body:any}[])=>Promise<void>) {
  const runtime=globalThis as any;
  const previous=runtime.netlifyIdentityContext;
  const previousNetlify=runtime.Netlify;
  runtime.Netlify={context:{cookies:{get(){return 'a'.repeat(64)}}}};
  const valid=mock.method(sessionStore,'userId',async()=>'00000000-0000-4000-8000-000000000001');
  const staffById=mock.method(staffStore,'byId',async()=>null);
  const staffAll=mock.method(staffStore,'all',async()=>[]);
  const original=globalThis.fetch;
  runtime.netlifyIdentityContext={url:'https://identity.example.test',token:'test-runtime-token'};
  const calls:{url:string;body:any}[]=[];
  globalThis.fetch=async(input,options)=>{
    const url=String(input);const body=options?.body?JSON.parse(String(options.body)):null;
    calls.push({url,body});
    if(url.endsWith('/user'))return Response.json({id:'00000000-0000-4000-8000-000000000001',app_metadata:{roles:[role]}});
    if(url.endsWith('/admin/users/00000000-0000-4000-8000-000000000001')) return Response.json({id:'00000000-0000-4000-8000-000000000001',app_metadata:{roles:[role]}});
    if(url.endsWith('/admin/users/00000000-0000-4000-8000-000000000002') && options?.method!=='PUT')return Response.json({id:'00000000-0000-4000-8000-000000000002',user_metadata:{full_name:'Nama lama',other:'keep'},app_metadata:{roles:['operator']}});
    if(url.endsWith('/admin/users/00000000-0000-4000-8000-000000000002'))return Response.json({id:'00000000-0000-4000-8000-000000000002',user_metadata:body.user_metadata,app_metadata:{roles:['operator']}});
    if(url.endsWith('/admin/users') && options?.method==='POST')return Response.json({id:'created',email:body.email,user_metadata:body.user_metadata,app_metadata:body.app_metadata});
    if(url.includes('/admin/users?'))return Response.json({users:[]});
    return Response.json({});
  };
  try{await run(calls);}finally{globalThis.fetch=original;runtime.netlifyIdentityContext=previous;runtime.Netlify=previousNetlify;valid.mock.restore();staffById.mock.restore();staffAll.mock.restore();}
}
function request(method:string,body:unknown,origin='https://site.example.test'){
 return new Request('https://site.example.test/.netlify/functions/accounts',{method,headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
}
test('roles come from server metadata, never editable user metadata',()=>{
  assert.equal(userRole({id:'x',userMetadata:{roles:['admin']}}),'');
  assert.equal(userRole({id:'x',appMetadata:{roles:['supervisor']}}),'supervisor');
  assert.deepEqual(publicUser({id:'x',email:'operator@example.test',userMetadata:{full_name:'Nama Operator'},appMetadata:{roles:['operator']}}),{id:'x',email:'operator@example.test',full_name:'Nama Operator',role:'operator'});
});
test('operator and supervisor cannot manage users or create administrators',async()=>{
 for(const role of ['operator','supervisor'])await identityHarness(role,async calls=>{
  for (const requestedRole of ['admin','operator','supervisor']) {
    assert.equal((await accounts(request('POST',{full_name:'Nama',email:'a@example.test',role:requestedRole}))).status,403);
  }
  assert.equal(calls.some(call=>call.body?.email),false);
 });
 await identityHarness('admin',async()=>{
   assert.equal((await accounts(request('POST',{full_name:'Nama',email:'a@example.test',role:'unknown'}))).status,400);
 });
});
test('admin accounts are created in Identity with a name, without exposing credentials',async()=>{
 for(const role of ['admin']) await identityHarness('admin',async calls=>{
   const response=await accounts(request('POST',{full_name:'  Nama Petugas  ',email:'petugas@example.test',role}));
   assert.equal(response.status,201);
   const result=await response.json();
   assert.equal(result.full_name,'Nama Petugas');assert.equal(result.role,role);
   assert.equal(result.password,undefined);
   const create=calls.find(call=>call.url.endsWith('/admin/users')&&call.body);
   assert.deepEqual(create?.body.app_metadata.roles,[role]);
 });
});
test('admin can change names while preserving existing metadata',async()=>{
 await identityHarness('admin',async()=>{
   const response=await accounts(request('PATCH',{id:'00000000-0000-4000-8000-000000000002',full_name:'Nama Baru'}));
   assert.equal(response.status,200);assert.equal((await response.json()).full_name,'Nama Baru');
 });
});
test('blank names, invalid email, and cross-origin writes are rejected',async()=>{
 await identityHarness('admin',async()=>{
  assert.equal((await accounts(request('POST',{full_name:'  ',email:'a@example.test',role:'admin'}))).status,400);
  assert.equal((await accounts(request('POST',{full_name:'Nama',email:'bad',role:'admin'}))).status,400);
  assert.equal((await accounts(request('POST',{full_name:'Nama',email:'a@example.test',role:'admin'},'https://other.example.test'))).status,403);
 });
});
test('unauthenticated account and operational requests fail before database access',async()=>{
 assert.equal((await accounts(new Request('https://site.example.test/accounts'))).status,401);
 assert.equal((await operations(new Request('https://site.example.test/operations'))).status,401);
});


test('monthly CSV endpoint authorizes the server role before processing export parameters',async()=>{
 for(const role of ['operator','unknown','admin','supervisor']) await identityHarness(role,async()=>{
   // Invalid parameters let managers reach validation without reading operational data.
   // Client-supplied roles must never grant an operator access.
   const response=await monthlyExport(new Request('https://site.example.test/.netlify/functions/monthly-export?month=invalid&role=admin',{
     headers:{'X-Role':'admin'},
   }));
   assert.equal(response.status,['admin','supervisor'].includes(role)?400:403);
   assert.equal(response.headers.get('Cache-Control'),'no-store');
   if(role==='operator') assert.equal((await response.json()).error,'Unduhan hanya untuk admin dan supervisor.');
 });
});
