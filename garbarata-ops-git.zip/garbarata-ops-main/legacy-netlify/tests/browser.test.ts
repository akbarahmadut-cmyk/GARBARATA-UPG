import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

function harness(fetcher:(url:string,options:any)=>Promise<Response>) {
 const elements=new Map<string,any>();
 const element=()=>({value:'',textContent:'',disabled:false,listeners:{} as Record<string,Function>,classList:{hidden:false,add(name:string){if(name==='hidden')this.hidden=true},remove(name:string){if(name==='hidden')this.hidden=false},toggle(name:string,force:boolean){if(name==='hidden')this.hidden=force}},addEventListener(name:string,fn:Function){this.listeners[name]=fn},reset(){},replaceChildren(){},appendChild(){},setAttribute(){}});
 const document={getElementById(id:string){if(!elements.has(id))elements.set(id,element());return elements.get(id)},querySelectorAll(){return ['registration','stand','activity','activityTime','activityNote'].map(id=>document.getElementById(id))},createElement:element};
 const context=vm.createContext({document,window:{location:{hash:'',href:'',pathname:'/'}},history:{replaceState(){}},Date,URL,URLSearchParams,AbortController,AbortSignal,setTimeout,clearTimeout,fetch:fetcher});
 const script=readFileSync('index.html','utf8').match(/<script>([\s\S]*?)<\/script>/)![1];
 new vm.Script(script).runInContext(context);
 return {context,document};
}
test('note save retry reuses the saved activity instead of duplicating it',async()=>{
 let inserts=0,attempts=0;
 const {context,document}=harness(async(url,options)=>{
  if(url.endsWith('/session'))return Response.json({error:'Login'},{status:401});
  if(url.endsWith('/operations')&&options.method==='POST'){inserts++;return Response.json({id:'activity-1'});}
  if(url.endsWith('/operations'))return Response.json({rows:[],profiles:[]});
  if(JSON.parse(options.body).operationId){attempts++;if(attempts===1)return Response.json({error:'Temporary failure'},{status:503});}
  return Response.json({});
 });
 await new Promise(resolve=>setImmediate(resolve));
 vm.runInContext('currentUser={id:"operator-1"};currentProfile={role:"operator"}',context);
 document.getElementById('activityNote').value='Periksa bridge';document.getElementById('activityTime').value='2026-11-06T10:00';
 const submit=document.getElementById('operationForm').listeners.submit;const event={preventDefault(){},target:document.getElementById('operationForm')};
 await submit(event);assert.equal(inserts,1);assert.equal(document.getElementById('registration').disabled,true);
 await submit(event);assert.equal(inserts,1);assert.equal(attempts,2);assert.equal(document.getElementById('registration').disabled,false);
});
test('failed login displays an error and enables another attempt',async()=>{
 const {context,document}=harness(async()=>Response.json({error:'Email atau password salah'},{status:401}));
 await new Promise(resolve=>setImmediate(resolve));
 await vm.runInContext('login()',context);
 assert.equal(document.getElementById('loginButton').disabled,false);
 assert.equal(document.getElementById('loginMessage').textContent,'Email atau password salah');
});

test('shift rollover clears operator history and counters before reloading; managers keep history',async()=>{
 const {context,document}=harness(async()=>Response.json({error:'Login'},{status:401}));
 await new Promise(resolve=>setImmediate(resolve));
 vm.runInContext('let reloads=0;loadRecords=async()=>{reloads++};',context);
 for(const role of ['admin','supervisor']){
  vm.runInContext('currentProfile={role:"'+role+'"};records=[{id:"old"}];shiftExpiresAt=Date.now()-1;refreshOperatorShift()',context);
  assert.equal(vm.runInContext('records.length',context),1);
  assert.equal(vm.runInContext('reloads',context),role==='admin'?1:2);
 }
 vm.runInContext('currentProfile={role:"operator"};operationNotes={old:"Catatan"};shiftExpiresAt=Date.now()-1;refreshOperatorShift()',context);
 assert.equal(vm.runInContext('records.length',context),0);
 assert.equal(vm.runInContext('Object.keys(operationNotes).length',context),0);
 assert.equal(document.getElementById('total').textContent,0);
 assert.equal(document.getElementById('docking').textContent,0);
 assert.equal(document.getElementById('undocking').textContent,0);
 assert.equal(vm.runInContext('reloads',context),3);
});

test('admin pages separate account creation, directory and operations; other roles stay on dashboard',async()=>{
 const {context,document}=harness(async(url)=>url.endsWith('/session')
  ? Response.json({error:'Login'},{status:401})
  : Response.json([]));
 await new Promise(resolve=>setImmediate(resolve));
 vm.runInContext('currentProfile={role:"admin"};window.location.hash="#manage-users";showPage()',context);
 assert.equal(document.getElementById('accountSection').classList.hidden,false);
 assert.equal(document.getElementById('usersSection').classList.hidden,true);
 assert.equal(document.getElementById('dashboardSection').classList.hidden,true);
 vm.runInContext('window.location.hash="#users";showPage()',context);
 assert.equal(document.getElementById('accountSection').classList.hidden,true);
 assert.equal(document.getElementById('usersSection').classList.hidden,false);
 assert.equal(document.getElementById('pageTitle').textContent,'Daftar User');
 for(const role of ['operator','supervisor']){
  vm.runInContext('currentProfile={role:"'+role+'"};showPage()',context);
  assert.equal(document.getElementById('usersSection').classList.hidden,true);
  assert.equal(document.getElementById('accountSection').classList.hidden,true);
  assert.equal(document.getElementById('dashboardSection').classList.hidden,false);
 }
});


test('monthly CSV controls follow the signed-in role and operator calls send no export request',async()=>{
 let role='operator';
 const exportRequests:string[]=[];
 const {context,document}=harness(async(url)=>{
   if(url.includes('monthly-export')) exportRequests.push(url);
   return url.endsWith('/session') ? Response.json({id:'user',role,full_name:'Petugas'}) : Response.json({rows:[],profiles:[]});
 });
 await new Promise(resolve=>setImmediate(resolve));
 vm.runInContext('loadRecords=async()=>{}',context);
 for(role of ['admin','supervisor','operator']){
   await vm.runInContext('checkSession()',context);
   assert.equal(document.getElementById('exportControls').classList.hidden,role==='operator');
 }
 await vm.runInContext('exportMonthlyCSV()',context);
 assert.deepEqual(exportRequests,[]);
 assert.equal(document.getElementById('exportMessage').textContent,'Unduhan hanya untuk admin dan supervisor.');
 vm.runInContext('showLogin()',context);
 assert.equal(document.getElementById('exportControls').classList.hidden,true);
});


test('leaderboard escapes operator names and resets for every role while managers retain history',async()=>{
 const {context,document}=harness(async()=>Response.json({error:'Login'},{status:401}));
 await new Promise(resolve=>setImmediate(resolve));
 vm.runInContext('loadRecords=async()=>{}',context);
 for(const role of ['operator','supervisor','admin']){
  vm.runInContext('currentProfile={role:"'+role+'"};records=[{id:"old"}];leaderboard=[{operator_id:"b",name:"Zaki",total:7},{operator_id:"a",name:"<Amin>",total:2}];renderLeaderboard()',context);
  assert.match(document.getElementById('leaderboardBody').innerHTML,/&lt;Amin&gt;/);
  assert.ok(document.getElementById('leaderboardBody').innerHTML.indexOf('Zaki')<document.getElementById('leaderboardBody').innerHTML.indexOf('&lt;Amin&gt;'));
  vm.runInContext('shiftExpiresAt=Date.now()-1;refreshOperatorShift()',context);
  assert.equal(vm.runInContext('leaderboard.every(row=>row.total===0)',context),true);
  assert.equal(vm.runInContext('leaderboard[0].operator_id',context),'a');
  assert.equal(vm.runInContext('records.length',context),role==='operator'?0:1);
 }
});

test('history requests pages beyond 500 records and keeps full totals with correct navigation',async()=>{
 const requests:string[]=[];
 const {context,document}=harness(async(url)=>{
  if(url.endsWith('/session')) return Response.json({error:'Login'},{status:401});
  requests.push(url);
  const requested=Number(new URL(url,'https://example.test').searchParams.get('page'));
  const page=Math.min(requested,51);
  return Response.json({rows:[],profiles:[],pagination:{page,pageSize:10,total:501,totalPages:51},stats:{total:501,docking:300,undocking:201}});
 });
 await new Promise(resolve=>setImmediate(resolve));
 vm.runInContext('currentProfile={role:"admin"}',context);
 await vm.runInContext('loadRecords(1)',context);
 assert.equal(document.getElementById('historyPrevious').disabled,true);
 assert.equal(document.getElementById('historyNext').disabled,false);
 await vm.runInContext('loadRecords(51)',context);
 assert.equal(document.getElementById('historyNext').disabled,true);
 assert.equal(document.getElementById('historyPrevious').disabled,false);
 assert.match(document.getElementById('historyPageInfo').textContent,/Halaman 51 dari 51/);
 assert.equal(document.getElementById('total').textContent,501);
 assert.equal(document.getElementById('docking').textContent,300);
 assert.equal(document.getElementById('undocking').textContent,201);
 assert.ok(requests.some(url=>url.endsWith('operations?page=51')));
 await vm.runInContext('loadRecords(52)',context);
 assert.equal(vm.runInContext('historyPage',context),51);
});

test('operational navigation opens one section at a time for every role and defaults to input',async()=>{
 const {context,document}=harness(async()=>Response.json({error:'Login'},{status:401}));
 await new Promise(resolve=>setImmediate(resolve));
 const routes=[['dashboard','dashboardSection','Input Operasional'],['history','historySection','Riwayat Operasional'],['leaderboard','leaderboardSection','Leaderboard Operator'],['summary','summarySection','Ringkasan Operasional']];
 for(const role of ['operator','supervisor','admin']){
  vm.runInContext('currentProfile={role:"'+role+'"};window.location.hash="";showPage()',context);
  assert.equal(document.getElementById('pageTitle').textContent,'Input Operasional');
  for(const [route,section,title] of routes){
   vm.runInContext('window.location.hash="#'+route+'";showPage()',context);
   assert.equal(document.getElementById('pageTitle').textContent,title);
   for(const [,other] of routes) assert.equal(document.getElementById(other).classList.hidden,other!==section);
   assert.equal(document.getElementById('usersSection').classList.hidden,true);
   assert.equal(document.getElementById('accountSection').classList.hidden,true);
  }
 }
});
