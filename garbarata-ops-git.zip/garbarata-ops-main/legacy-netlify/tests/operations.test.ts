import { test } from 'node:test';
import assert from 'node:assert/strict';
import { operatorShift, monthBounds, csvCell, monthlyOperations, requireManager, HttpError } from '../server/operations.js';
import exportHandler from '../netlify/functions/monthly-export.mjs';
import notesHandler from '../netlify/functions/operation-notes.mjs';

test('WITA shifts switch at 08:00, 14:00 and 20:00 and span midnight and month boundaries', () => {
  for (const [time,start,end] of [
    ['2026-11-01T07:59:59.999+08:00','2026-10-31T20:00:00+08:00','2026-11-01T08:00:00+08:00'],
    ['2026-11-01T08:00:00+08:00','2026-11-01T08:00:00+08:00','2026-11-01T14:00:00+08:00'],
    ['2026-11-01T13:59:59.999+08:00','2026-11-01T08:00:00+08:00','2026-11-01T14:00:00+08:00'],
    ['2026-11-01T14:00:00+08:00','2026-11-01T14:00:00+08:00','2026-11-01T20:00:00+08:00'],
    ['2026-11-01T19:59:59.999+08:00','2026-11-01T14:00:00+08:00','2026-11-01T20:00:00+08:00'],
    ['2026-12-31T20:00:00+08:00','2026-12-31T20:00:00+08:00','2027-01-01T08:00:00+08:00'],
    ['2027-01-01T00:00:00+08:00','2026-12-31T20:00:00+08:00','2027-01-01T08:00:00+08:00'],
  ]) assert.deepEqual(operatorShift(new Date(time)),{start:new Date(start).toISOString(),end:new Date(end).toISOString()});
});

test('monthly bounds include local start and exclude next month, including leap years', () => {
  assert.deepEqual(monthBounds('2024-02','-420'), ['2024-01-31T17:00:00.000Z','2024-02-29T17:00:00.000Z']);
  assert.deepEqual(monthBounds('2026-12','-480'), ['2026-11-30T16:00:00.000Z','2026-12-31T16:00:00.000Z']);
  for(const value of ['2026-00','2026-13','2026-1','bad']) assert.throws(()=>monthBounds(value,'0'),HttpError);
  assert.throws(()=>monthBounds('2026-11','invalid'),HttpError);
});

test('CSV quotes commas, quotes and multiline notes, and neutralizes spreadsheet formulas', () => {
  assert.equal(csvCell('Cuaca, "hujan"\nPeriksa bridge'),'"Cuaca, ""hujan""\nPeriksa bridge"');
  assert.equal(csvCell(null),'""');
  for(const value of ['=SUM(A1)',' +cmd','@SUM(A1)','-1','\t=1']) assert.equal(csvCell(value),'"\''+value+'"');
});

test('monthly export fetches beyond dashboard limit and applies stable sort and date range', async () => {
  const pages: number[] = [];
  const result = await monthlyOperations(async path => {
    const query = new URL('https://example.test/'+path).searchParams;
    assert.equal(query.get('deleted_at'),'is.null');
    assert.equal(query.get('order'),'activity_time.asc,id.asc');
    assert.equal(query.get('and'),'(activity_time.gte.start,activity_time.lt.end)');
    const offset=Number(query.get('offset'));pages.push(offset);
    return Array.from({length:offset===1000?1:500},(_,i)=>({id:offset+i}));
  },'start','end');
  assert.equal(result.length,1001);
  assert.deepEqual(pages,[0,500,1000]);
});

test('only admin and supervisor pass server authorization', async () => {
  for(const role of ['admin','supervisor']) await requireManager(async()=>[{role}], 'user');
  for(const role of ['operator','',null]) await assert.rejects(requireManager(async()=>[{role}], 'user'),{status:403});
  await assert.rejects(requireManager(async()=>[], 'user'),{status:403});
});

test('endpoints reject unauthenticated requests and unsupported methods', async () => {
  assert.equal((await exportHandler(new Request('https://example.test/export'))).status,401);
  assert.equal((await notesHandler(new Request('https://example.test/notes',{method:'POST',headers:{origin:'https://example.test'},body:'{}'}))).status,401);
  assert.equal((await notesHandler(new Request('https://example.test/notes'))).status,405);
});
