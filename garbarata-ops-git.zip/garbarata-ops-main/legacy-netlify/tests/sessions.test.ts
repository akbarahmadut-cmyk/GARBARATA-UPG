import { test, mock } from 'node:test';
import assert from 'node:assert/strict';
import { startSession, validSession, endSession, sessionUserId, sessionStore, SESSION_SECONDS } from '../server/sessions.js';

test('session expires five hours after login, cannot extend with activity, and logout revokes it', async()=>{
  const runtime=globalThis as any;
  const previous=runtime.Netlify;
  const values=new Map<string,string>();
  let expires=0;
  let storedHash='';
  let storedUser='';
  let options:any;
  runtime.Netlify={context:{cookies:{
    get(name:string){return values.get(name)},
    set(cookie:any){options=cookie;values.set(cookie.name,cookie.value)},
    delete(name:string){values.delete(name)},
  }}};
  const created=mock.method(sessionStore,'create',async(id:string,user:string,deadline:Date)=>{
    storedHash=id;storedUser=user;expires=deadline.getTime();
  });
  const valid=mock.method(sessionStore,'valid',async(id:string,user:string,now:Date)=>
    id===storedHash && user===storedUser && now.getTime()<expires);
  const lookup=mock.method(sessionStore,'userId',async(id:string)=>
    id===storedHash && Date.now()<expires ? storedUser : null);
  const removed=mock.method(sessionStore,'remove',async()=>{storedHash=''});
  const now=mock.method(Date,'now',()=>1000000);
  try {
    await startSession('operator-1');
    assert.equal(SESSION_SECONDS,18000);
    assert.equal(expires,1000000+18000000);
    assert.equal(options.httpOnly,true);
    assert.equal(options.secure,true);
    assert.equal(options.maxAge,18000);
    assert.notEqual(options.value,storedHash);
    // Date constructor is separate from Date.now; use a clock in the validation mock.
    valid.mock.mockImplementation(async(id:string,user:string)=>
      id===storedHash && user===storedUser && Date.now()<expires);
    assert.equal(await sessionUserId(),'operator-1');
    assert.equal(await validSession('operator-1'),true);
    assert.equal(await validSession('other-user'),false);
    now.mock.mockImplementation(()=>expires-1);
    assert.equal(await sessionUserId(),'operator-1');
    assert.equal(await validSession('operator-1'),true);
    assert.equal(created.mock.callCount(),1);
    now.mock.mockImplementation(()=>expires);
    assert.equal(await sessionUserId(),null);
    assert.equal(await validSession('operator-1'),false);
    await endSession();
    assert.equal(values.size,0);
    assert.equal(storedHash,'');
    assert.equal(await sessionUserId(),null);
    assert.equal(await validSession('operator-1'),false);
  } finally {
    now.mock.restore();created.mock.restore();valid.mock.restore();removed.mock.restore();lookup.mock.restore();
    runtime.Netlify=previous;
  }
});
