import { inArray } from 'drizzle-orm';
import { database } from '../../db/index.js';
import { operationNotes } from '../../db/schema.js';
import { authenticate, upstream, requireManager, monthBounds, monthlyOperations, csvCell, errorResponse, HttpError } from '../../server/operations.js';

export default async (req: Request) => {
  try {
    if (req.method !== 'GET') return new Response(null, { status: 405 });
    const read = upstream(req);
    const user = await authenticate(read);
    await requireManager(read, user.id);
    const params = new URL(req.url).searchParams;
    const month = params.get('month') ?? '';
    const offset = params.get('offset') ?? '0';
    const [start, end] = monthBounds(month, offset);
    const rows = await monthlyOperations(read, start, end);
    if (!rows.length) throw new HttpError(404, 'Tidak ada kegiatan pada bulan yang dipilih.');
    const notes: Record<string, string> = {};
    const operators: Record<string, { full_name?: string; email?: string; login_id?: string }> = {};
    for (let i = 0; i < rows.length; i += 500) {
      const batch = await database().select().from(operationNotes).where(inArray(operationNotes.operationId, rows.slice(i,i+500).map(row => row.id)));
      for (const note of batch) notes[note.operationId] = note.note;
    }
    const operatorIds = [...new Set(rows.map(row => row.operator_id))].filter(Boolean);
    for (let i = 0; i < operatorIds.length; i += 50) {
      const profiles = await read(`rest/v1/profiles?select=id,full_name,email&id=in.(${operatorIds.slice(i,i+50).map(encodeURIComponent).join(',')})`);
      for (const profile of profiles) operators[profile.id] = profile;
    }
    const csv = [['Registrasi','Stand','Aktivitas','Waktu aktivitas (lokal)','Operator ID','Nama operator','Email / ID login operator','Catatan'],
      ...rows.map(row => [row.aircraft_registration,row.parking_stand,row.activity,
        new Date(new Date(row.activity_time).getTime() - Number(offset)*60000).toISOString().slice(0,19).replace('T',' '),
        row.operator_id,operators[row.operator_id]?.full_name,operators[row.operator_id]?.email || operators[row.operator_id]?.login_id,notes[row.id]])]
      .map(row => row.map(csvCell).join(',')).join('\r\n');
    return new Response('\uFEFF' + csv + '\r\n', { headers: { 'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="rekap-operasional-${month}.csv"`, 'Cache-Control': 'no-store' } });
  } catch (error) { return errorResponse(error); }
};
