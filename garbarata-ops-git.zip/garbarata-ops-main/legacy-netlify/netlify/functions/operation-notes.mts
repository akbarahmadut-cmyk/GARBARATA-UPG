import { inArray } from 'drizzle-orm';
import { database } from '../../db/index.js';
import { operationNotes } from '../../db/schema.js';
import { authenticate, upstream, HttpError, errorResponse, sameOrigin } from '../../server/operations.js';

export default async (req: Request) => {
  try {
    if (req.method !== 'POST') return new Response(null, { status: 405 });
    sameOrigin(req);
    const read = upstream(req);
    const user = await authenticate(read);
    const body = await req.json();
    const ids: string[] = body.ids ?? [body.operationId];
    if (!Array.isArray(ids) || ids.length > 500 || ids.some(id => typeof id !== 'string' || !/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i.test(id))) {
      throw new HttpError(400, 'ID kegiatan tidak valid.');
    }
    const visible = [];
    for (let i = 0; i < ids.length; i += 50) {
      const rows = await read(`rest/v1/operations?select=id,operator_id&id=in.(${ids.slice(i,i+50).join(',')})&deleted_at=is.null`);
      visible.push(...rows);
    }
    if (body.operationId !== undefined) {
      if (typeof body.note !== 'string' || body.note.length > 2000) throw new HttpError(400, 'Catatan maksimal 2000 karakter.');
      if (visible.length !== 1 || visible[0].operator_id !== user.id) throw new HttpError(403, 'Catatan hanya dapat disimpan oleh operator kegiatan.');
      await database().insert(operationNotes).values({ operationId: body.operationId, authorId: user.id, note: body.note.trim() })
        .onConflictDoUpdate({ target: operationNotes.operationId, set: { note: body.note.trim() } });
      return Response.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } });
    }
    const allowed = visible.map(row => row.id);
    const notes = allowed.length ? await database().select().from(operationNotes).where(inArray(operationNotes.operationId, allowed)) : [];
    return Response.json(Object.fromEntries(notes.map(row => [row.operationId, row.note])), { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) { return errorResponse(error); }
};
