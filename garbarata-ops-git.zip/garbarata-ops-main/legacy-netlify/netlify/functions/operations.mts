import { and, count, desc, eq, gte, isNull, lt } from 'drizzle-orm';
import { database } from '../../db/index.js';
import { operations } from '../../db/schema.js';
import { identityUser, userRole, operatorShift, allUsers, publicUser, sameOrigin, HttpError, errorResponse } from '../../server/operations.js';

export default async (req: Request) => {
  try {
    if (!['GET','POST','DELETE'].includes(req.method)) return new Response(null,{status:405});
    const user=await identityUser();
    if (req.method==='GET') {
      const now=new Date();
      const leaderboardShift=operatorShift(now);
      const shift=userRole(user)==='operator' ? leaderboardShift : null;
      const condition=and(isNull(operations.deleted_at),shift ? gte(operations.activity_time,shift.start) : undefined,shift ? lt(operations.activity_time,shift.end) : undefined);
      const requestedPage=Number(new URL(req.url).searchParams.get('page') || '1');
      if(!Number.isSafeInteger(requestedPage) || requestedPage<1) throw new HttpError(400,'Halaman tidak valid.');
      const activityTotals=await database().select({activity:operations.activity,total:count()}).from(operations).where(condition).groupBy(operations.activity);
      const total=activityTotals.reduce((sum,row)=>sum+row.total,0);
      const totalPages=Math.max(1,Math.ceil(total/10));
      const page=Math.min(requestedPage,totalPages);
      const rows=await database().select().from(operations).where(condition).orderBy(desc(operations.activity_time),desc(operations.id)).limit(10).offset((page-1)*10);
      const stats={total,docking:activityTotals.find(row=>row.activity==='Docking')?.total ?? 0,undocking:activityTotals.find(row=>row.activity==='Undocking')?.total ?? 0};
      const totals=await database().select({operator_id:operations.operator_id,total:count()}).from(operations)
        .where(and(isNull(operations.deleted_at),gte(operations.activity_time,leaderboardShift.start),lt(operations.activity_time,leaderboardShift.end)))
        .groupBy(operations.operator_id);
      const profiles=(await allUsers()).map(publicUser);
      const counts=new Map(totals.map(row=>[row.operator_id,row.total]));
      const leaderboard=profiles.filter(profile=>profile.role==='operator' && profile.active!==false).map(profile=>({
        operator_id:profile.id,name:profile.full_name || profile.email || profile.id,total:counts.get(profile.id) ?? 0
      })).sort((a,b)=>b.total-a.total || a.name.localeCompare(b.name,'id') || a.operator_id.localeCompare(b.operator_id));
      return Response.json({rows,pagination:{page,pageSize:10,total,totalPages},stats,shift,leaderboard,leaderboardShift,serverTime:now.toISOString(),profiles},{headers:{'Cache-Control':'no-store'}});
    }
    sameOrigin(req);
    const body=await req.json();
    if (req.method==='DELETE') {
      if (!['admin','supervisor'].includes(userRole(user))) throw new HttpError(403,'Hanya admin dan supervisor dapat menghapus kegiatan.');
      if (typeof body.id!=='string' || !/^[\da-f-]{36}$/i.test(body.id)) throw new HttpError(400,'ID tidak valid.');
      await database().update(operations).set({deleted_at:new Date().toISOString(),deleted_by:user.id}).where(and(eq(operations.id,body.id),isNull(operations.deleted_at)));
      return Response.json({ok:true});
    }
    for (const key of ['aircraft_registration','parking_stand']) {
      if(typeof body[key]!=='string'||!body[key].trim()||body[key].length>100) throw new HttpError(400,'Lengkapi data kegiatan, maksimal 100 karakter per kolom.');
    }
    if (!['Docking','Undocking'].includes(body.activity)||typeof body.activity_time!=='string'||!Number.isFinite(Date.parse(body.activity_time))) throw new HttpError(400,'Aktivitas atau waktu tidak valid.');
    const [saved]=await database().insert(operations).values({flight_number:'',aircraft_registration:body.aircraft_registration.trim(),parking_stand:body.parking_stand.trim(),activity:body.activity,activity_time:body.activity_time,operator_id:user.id}).returning({id:operations.id});
    return Response.json(saved,{status:201});
  } catch(error) { return errorResponse(error); }
};
