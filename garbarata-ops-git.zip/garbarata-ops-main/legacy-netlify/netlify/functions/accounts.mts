import { admin, AuthError, requestPasswordRecovery } from '@netlify/identity';
import { randomBytes } from 'node:crypto';
import { identityUser, userRole, publicUser, allUsers, sameOrigin, HttpError, errorResponse } from '../../server/operations.js';
import { staffStore, staffUser, hashPin, validPin, normalizeLoginId, validLoginId, STAFF_ROLES } from '../../server/staff.js';
import { sessionStore } from '../../server/sessions.js';

const PIN_ERROR = 'PIN harus 6–12 digit angka.';
const LOGIN_ID_ERROR = 'ID login 3–32 karakter: huruf, angka, titik, garis bawah, atau tanda hubung.';

export default async (req: Request) => {
  try {
    if (!['GET','POST','PATCH'].includes(req.method)) return new Response(null,{status:405});
    const actor = await identityUser();
    if (userRole(actor) !== 'admin') throw new HttpError(403,'Pengelolaan user hanya untuk admin.');
    if (req.method === 'GET') return Response.json((await allUsers()).map(publicUser),{headers:{'Cache-Control':'no-store'}});
    sameOrigin(req);
    const body = await req.json();
    const name = typeof body.full_name === 'string' ? body.full_name.trim() : '';
    if (!name || name.length>100) throw new HttpError(400,'Nama wajib diisi, maksimal 100 karakter.');
    if (req.method === 'PATCH') {
      if (typeof body.id !== 'string') throw new HttpError(400,'User tidak valid.');
      const staff = await staffStore.byId(body.id);
      if (staff) {
        if (body.pin !== undefined && body.pin !== '' && !validPin(body.pin)) throw new HttpError(400,PIN_ERROR);
        if (body.role !== undefined && !STAFF_ROLES.includes(body.role)) throw new HttpError(400,'Pilih peran operator atau supervisor.');
        if (body.active !== undefined && typeof body.active !== 'boolean') throw new HttpError(400,'Status akun tidak valid.');
        const pinHash = body.pin ? await hashPin(body.pin) : undefined;
        const updated = await staffStore.update(staff.id,{fullName:name, ...(pinHash ? {pinHash} : {}),
          ...(body.role ? {role:body.role} : {}), ...(body.active !== undefined ? {active:body.active} : {})});
        // A new PIN, role change or deactivation signs the account out everywhere.
        if (pinHash || body.active === false || (body.role && body.role !== staff.role)) await sessionStore.removeForUser(staff.id);
        return Response.json(publicUser(staffUser(updated!)),{headers:{'Cache-Control':'no-store'}});
      }
      const target = await admin.getUser(body.id);
      if (!['operator','supervisor'].includes(userRole(target))) throw new HttpError(403,'Nama hanya dapat diatur untuk operator dan supervisor.');
      const updated = await admin.updateUser(target.id,{user_metadata:{...target.userMetadata,full_name:name}});
      return Response.json(publicUser(updated),{headers:{'Cache-Control':'no-store'}});
    }
    if (!['admin','operator','supervisor'].includes(body.role)) throw new HttpError(400,'Pilih peran admin, operator, atau supervisor.');
    if (STAFF_ROLES.includes(body.role)) {
      const loginId = normalizeLoginId(body.login_id);
      if (!validLoginId(loginId)) throw new HttpError(400,LOGIN_ID_ERROR);
      if (!validPin(body.pin)) throw new HttpError(400,PIN_ERROR);
      const created = await staffStore.create({loginId,fullName:name,role:body.role,pinHash:await hashPin(body.pin)});
      if (!created) throw new HttpError(409,'ID login sudah dipakai. Gunakan ID lain.');
      return Response.json(publicUser(staffUser(created)),{status:201,headers:{'Cache-Control':'no-store'}});
    }
    if (typeof body.email !== 'string' || body.email.length>254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email.trim())) throw new HttpError(400,'Email tidak valid.');
    const created = await admin.createUser({email:body.email.trim().toLowerCase(), password:randomBytes(48).toString('base64url'),
      data:{user_metadata:{full_name:name},app_metadata:{roles:[body.role]}}});
    let emailSent = true;
    try { await requestPasswordRecovery(created.email!); } catch { emailSent = false; }
    return Response.json({...publicUser(created),emailSent},{status:201,headers:{'Cache-Control':'no-store'}});
  } catch (error) {
    if (error instanceof AuthError) return errorResponse(new HttpError(error.status === 422 ? 409 : 503,
      error.status === 422 ? 'Email sudah terdaftar atau tidak valid.' : 'Layanan akun belum tersedia. Silakan coba lagi.'));
    return errorResponse(error);
  }
};
