import { startSession, endSession } from '../../server/sessions.js';
import { login, logout, acceptInvite, recoverPassword, requestPasswordRecovery } from '@netlify/identity';
import { staffLogin, StaffLoginError } from '../../server/staff.js';
import { identityUser, publicUser, sameOrigin, HttpError, errorResponse } from '../../server/operations.js';

export default async (req: Request) => {
  try {
    if (req.method === 'GET') return Response.json(publicUser(await identityUser()),{headers:{'Cache-Control':'no-store'}});
    if (req.method !== 'POST') return new Response(null,{status:405});
    sameOrigin(req);
    const body = await req.json();
    if (body.action === 'logout') { await endSession(); try { await logout(); } catch { /* Staff sessions have no Identity cookie. */ } return Response.json({ok:true}); }
    if (body.action === 'staff-login') {
      try {
        const account = await staffLogin(body.login_id, body.pin);
        await startSession(account.id);
      } catch (error) {
        if (error instanceof StaffLoginError) throw new HttpError(401, error.message);
        throw error;
      }
      return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});
    }
    if (body.action === 'recover') {
      if (typeof body.email !== 'string' || body.email.length>254) throw new HttpError(400,'Masukkan email akun.');
      try { await requestPasswordRecovery(body.email); } catch { /* Keep account existence private. */ }
      return Response.json({ok:true});
    }
    if (typeof body.password !== 'string' || !body.password || typeof body.email !== 'string') throw new HttpError(400,'Email dan password wajib diisi.');
    if (body.action === 'accept') {
      if (body.password.length<10) throw new HttpError(400,'Password minimal 10 karakter.');
      if (typeof body.token !== 'string' || !body.token) throw new HttpError(400,'Tautan tidak valid.');
      if (body.type === 'invite') await acceptInvite(body.token,body.password);
      else if (body.type === 'recovery') await recoverPassword(body.token,body.password);
      else throw new HttpError(400,'Tautan tidak valid.');
    } else if (body.action !== 'login') throw new HttpError(400,'Permintaan tidak valid.');
    const user = await login(body.email,body.password);
    try { await startSession(user.id); } catch (error) { await logout(); throw error; }
    return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});
  } catch (error) {
    if (error instanceof HttpError) return errorResponse(error);
    return errorResponse(new HttpError(401,'Login atau tautan tidak valid. Periksa email dan password, atau minta tautan baru.'));
  }
};
