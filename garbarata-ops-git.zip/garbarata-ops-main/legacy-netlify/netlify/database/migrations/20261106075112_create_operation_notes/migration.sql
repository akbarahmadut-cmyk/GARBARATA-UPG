CREATE TABLE "operation_notes" (
	"operation_id" uuid PRIMARY KEY,
	"author_id" uuid NOT NULL,
	"note" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
