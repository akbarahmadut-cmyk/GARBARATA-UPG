CREATE TABLE "user_sessions" (
	"id_hash" text PRIMARY KEY,
	"user_id" uuid NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
