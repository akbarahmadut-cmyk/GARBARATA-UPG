CREATE TABLE "operations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"flight_number" text NOT NULL,
	"aircraft_registration" text NOT NULL,
	"parking_stand" text NOT NULL,
	"activity" text NOT NULL,
	"activity_time" timestamp with time zone NOT NULL,
	"operator_id" uuid NOT NULL,
	"deleted_at" timestamp with time zone,
	"deleted_by" uuid
);
