// Tes end-to-end Worker. D1 digantikan SQLite bawaan Node (node:sqlite) yang
// menjalankan migrations/0001_init.sql yang sama dengan produksi.
import { test, before } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import worker from "../worker.js";

const ORIGIN = "https://ops.test";

function createD1() {
  const db = new DatabaseSync(":memory:");
  db.exec(readFileSync(new URL("../migrations/0001_init.sql", import.meta.url), "utf8"));
  const wrap = (sql, params = []) => ({
    bind: (...values) => wrap(sql, values),
    first: async () => db.prepare(sql).get(...params) ?? null,
    all: async () => ({ results: db.prepare(sql).all(...params) }),
    run: async () => {
      const r = db.prepare(sql).run(...params);
      return { success: true, meta: { changes: Number(r.changes) } };
    }
  });
  return { prepare: sql => wrap(sql), exec: sql => db.exec(sql) };
}

const env = {
  DB: createD1(),
  ASSETS: { fetch: async () => new Response("<html>aset</html>", { headers: { "Content-Type": "text/html" } }) }
};

async function call(path, { method = "GET", body, cookie, origin = ORIGIN } = {}) {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (cookie) headers.Cookie = cookie;
  if (origin && method !== "GET") headers.Origin = origin;
  const response = await worker.fetch(new Request(ORIGIN + path, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body)
  }), env);
  const type = response.headers.get("Content-Type") || "";
  const data = type.includes("json") ? await response.json() : await response.text();
  const setCookie = response.headers.get("Set-Cookie");
  return { status: response.status, data, response, cookie: setCookie ? setCookie.split(";")[0] : null };
}

const sessions = {};
async function loginAs(name, loginId, pin) {
  const r = await call("/api/session", { method: "POST", body: { action: "staff-login", login_id: loginId, pin } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  sessions[name] = r.cookie;
  return r;
}

before(async () => {
  const r = await call("/api/setup-admin", {
    method: "POST", body: { login_id: "admin1", full_name: "Admin Utama", pin: "123456" }
  });
  assert.equal(r.status, 201);
  sessions.admin = r.cookie;
});

test("health tidak membocorkan nama tabel", async () => {
  const r = await call("/api/health");
  assert.equal(r.status, 200);
  assert.deepEqual(r.data, { status: "ok", database: "connected" });
});

test("setup admin hanya sekali dan halaman setup menutup", async () => {
  const again = await call("/api/setup-admin", {
    method: "POST", body: { login_id: "admin2", full_name: "Lain", pin: "654321" }
  });
  assert.equal(again.status, 409);
  const page = await call("/setup-admin");
  assert.match(page.data, /sudah dibuat/i);
});

test("setup admin menolak origin lain", async () => {
  const r = await call("/api/setup-admin", {
    method: "POST", origin: "https://evil.example",
    body: { login_id: "x", full_name: "x", pin: "123456" }
  });
  assert.equal(r.status, 403);
});

test("path /api tak dikenal menghasilkan 404 JSON, selain itu ke aset", async () => {
  assert.equal((await call("/api/tidak-ada")).status, 404);
  const asset = await call("/index.html");
  assert.equal(asset.status, 200);
  assert.match(asset.data, /aset/);
});

test("admin membuat operator, supervisor, dan admin kedua", async () => {
  for (const [id, name, role] of [
    ["OPR1", "Budi Operator", "operator"],
    ["opr2", "Citra Operator", "operator"],
    ["SPV1", "Dewi Supervisor", "supervisor"]
  ]) {
    const r = await call("/api/accounts", {
      method: "POST", cookie: sessions.admin,
      body: { full_name: name, role, login_id: id, pin: "111222" }
    });
    assert.equal(r.status, 201, JSON.stringify(r.data));
    assert.equal(r.data.login_id, id.toUpperCase());
    assert.equal(r.data.pin_hash, undefined);
  }
  const dup = await call("/api/accounts", {
    method: "POST", cookie: sessions.admin,
    body: { full_name: "Dobel", role: "operator", login_id: "opr1", pin: "111222" }
  });
  assert.equal(dup.status, 409);
  const bad = await call("/api/accounts", {
    method: "POST", cookie: sessions.admin,
    body: { full_name: "X", role: "operator", login_id: "OPR9", pin: "12ab" }
  });
  assert.equal(bad.status, 400);

  await loginAs("opr1", "opr1", "111222"); // huruf kecil tetap bisa masuk
  await loginAs("opr2", "OPR2", "111222");
  await loginAs("spv", "SPV1", "111222");

  const list = await call("/api/accounts", { cookie: sessions.admin });
  assert.equal(list.data.length, 4);
});

test("non-admin tidak boleh mengelola akun", async () => {
  assert.equal((await call("/api/accounts", { cookie: sessions.opr1 })).status, 403);
  assert.equal((await call("/api/accounts", { cookie: sessions.spv })).status, 403);
  assert.equal((await call("/api/accounts")).status, 401);
});

test("PIN salah 5x mengunci akun, PIN benar pun ditolak saat terkunci", async () => {
  await call("/api/accounts", {
    method: "POST", cookie: sessions.admin,
    body: { full_name: "Korban Kunci", role: "operator", login_id: "LOCK1", pin: "999888" }
  });
  for (let i = 0; i < 5; i++) {
    const r = await call("/api/session", { method: "POST", body: { action: "staff-login", login_id: "LOCK1", pin: "000000" } });
    assert.equal(r.status, 401);
  }
  const locked = await call("/api/session", { method: "POST", body: { action: "staff-login", login_id: "LOCK1", pin: "999888" } });
  assert.equal(locked.status, 423);
  const unknown = await call("/api/session", { method: "POST", body: { action: "staff-login", login_id: "TIDAKADA", pin: "000000" } });
  assert.equal(unknown.status, 401);
});

test("operator mencatat kegiatan, melihat shift sendiri, dan menyimpan catatan", async () => {
  const now = new Date().toISOString();
  const created = await call("/api/operations", {
    method: "POST", cookie: sessions.opr1,
    body: { aircraft_registration: "PK-GFA", parking_stand: "A1", activity: "Docking", activity_time: now }
  });
  assert.equal(created.status, 201);
  const opId = created.data.id;

  const invalid = await call("/api/operations", {
    method: "POST", cookie: sessions.opr1,
    body: { aircraft_registration: "", parking_stand: "A1", activity: "Docking", activity_time: now }
  });
  assert.equal(invalid.status, 400);

  // operator lain tidak boleh menulis catatan di kegiatan ini
  const forbidden = await call("/api/operation-notes", {
    method: "POST", cookie: sessions.opr2, body: { operationId: opId, note: "curang" }
  });
  assert.equal(forbidden.status, 403);

  const saved = await call("/api/operation-notes", {
    method: "POST", cookie: sessions.opr1, body: { operationId: opId, note: "Garbarata lambat" }
  });
  assert.equal(saved.status, 200);
  await call("/api/operation-notes", {
    method: "POST", cookie: sessions.opr1, body: { operationId: opId, note: "Garbarata lambat (revisi)" }
  });

  const notes = await call("/api/operation-notes", {
    method: "POST", cookie: sessions.opr1, body: { ids: [opId] }
  });
  assert.deepEqual(notes.data, { [opId]: "Garbarata lambat (revisi)" });

  const list = await call("/api/operations?page=1", { cookie: sessions.opr1 });
  assert.equal(list.status, 200);
  assert.equal(list.data.rows.length, 1);
  assert.equal(list.data.stats.docking, 1);
  assert.equal(list.data.pagination.totalPages, 1);
  assert.ok(list.data.shift);
  const board = Object.fromEntries(list.data.leaderboard.map(r => [r.name, r.total]));
  assert.equal(board["Budi Operator"], 1);
  assert.equal(board["Citra Operator"], 0);
  assert.equal(list.data.profiles.find(p => p.id === list.data.rows[0].operator_id).full_name, "Budi Operator");
  assert.equal(list.data.profiles[0].login_id, undefined); // data minimal
});

test("paginasi 10 baris per halaman dan halaman di luar batas dirapikan", async () => {
  for (let i = 0; i < 12; i++) {
    const r = await call("/api/operations", {
      method: "POST", cookie: sessions.opr2,
      body: { aircraft_registration: "PK-" + i, parking_stand: "B" + i, activity: i % 2 ? "Undocking" : "Docking", activity_time: new Date(Date.now() - i * 1000).toISOString() }
    });
    assert.equal(r.status, 201);
  }
  const p2 = await call("/api/operations?page=2", { cookie: sessions.admin });
  assert.equal(p2.data.pagination.total, 13);
  assert.equal(p2.data.pagination.totalPages, 2);
  assert.equal(p2.data.rows.length, 3);
  const far = await call("/api/operations?page=99", { cookie: sessions.admin });
  assert.equal(far.data.pagination.page, 2);
  assert.equal((await call("/api/operations?page=abc", { cookie: sessions.admin })).status, 400);
  // operator hanya menghitung kegiatan shift aktif (semua milik shift ini)
  const opr = await call("/api/operations", { cookie: sessions.opr1 });
  assert.equal(opr.data.stats.total, 13);
});

test("operator tidak boleh menghapus; supervisor boleh (soft delete)", async () => {
  const list = await call("/api/operations", { cookie: sessions.spv });
  const id = list.data.rows[0].id;
  assert.equal((await call("/api/operations", { method: "DELETE", cookie: sessions.opr1, body: { id } })).status, 403);
  assert.equal((await call("/api/operations", { method: "DELETE", cookie: sessions.spv, body: { id } })).status, 200);
  assert.equal((await call("/api/operations", { method: "DELETE", cookie: sessions.spv, body: { id: "bukan-uuid" } })).status, 400);
  const after = await call("/api/operations", { cookie: sessions.spv });
  assert.equal(after.data.pagination.total, 12);
});

test("rekap CSV: hanya admin/supervisor, BOM, anti formula-injection, 404 bila kosong", async () => {
  await call("/api/operations", {
    method: "POST", cookie: sessions.opr1,
    body: { aircraft_registration: "=CMD()", parking_stand: 'S"1', activity: "Docking", activity_time: new Date().toISOString() }
  });
  const month = new Date().toISOString().slice(0, 7);

  assert.equal((await call(`/api/monthly-export?month=${month}&offset=-480`, { cookie: sessions.opr1 })).status, 403);

  const ok = await call(`/api/monthly-export?month=${month}&offset=-480`, { cookie: sessions.spv });
  assert.equal(ok.status, 200);
  assert.match(ok.response.headers.get("Content-Disposition"), /rekap-operasional-/);
  // Response.text() membuang BOM, jadi periksa byte mentahnya (EF BB BF) untuk Excel.
  const raw = await worker.fetch(new Request(ORIGIN + `/api/monthly-export?month=${month}&offset=-480`, {
    headers: { Cookie: sessions.spv }
  }), env);
  assert.deepEqual([...new Uint8Array(await raw.arrayBuffer()).slice(0, 3)], [0xef, 0xbb, 0xbf]);
  assert.match(ok.data, /"Registrasi","Stand","Aktivitas"/);
  assert.match(ok.data, /"'=CMD\(\)"/);       // rumus dinetralkan
  assert.match(ok.data, /"S""1"/);            // tanda kutip di-escape
  assert.match(ok.data, /"Budi Operator","OPR1"/);

  assert.equal((await call(`/api/monthly-export?month=2001-01&offset=0`, { cookie: sessions.spv })).status, 404);
  assert.equal((await call(`/api/monthly-export?month=bukan&offset=0`, { cookie: sessions.spv })).status, 400);
});

test("ganti PIN / nonaktifkan mengakhiri sesi; admin tak bisa menonaktifkan diri sendiri", async () => {
  const list = await call("/api/accounts", { cookie: sessions.admin });
  const opr2 = list.data.find(u => u.login_id === "OPR2");
  const admin = list.data.find(u => u.login_id === "ADMIN1");

  const changed = await call("/api/accounts", {
    method: "PATCH", cookie: sessions.admin,
    body: { id: opr2.id, full_name: "Citra Baru", pin: "777666", role: "operator", active: true }
  });
  assert.equal(changed.status, 200);
  assert.equal((await call("/api/session", { cookie: sessions.opr2 })).status, 401); // sesi lama mati
  await loginAs("opr2", "OPR2", "777666");

  const off = await call("/api/accounts", {
    method: "PATCH", cookie: sessions.admin,
    body: { id: opr2.id, full_name: "Citra Baru", active: false }
  });
  assert.equal(off.status, 200);
  assert.equal((await call("/api/session", { cookie: sessions.opr2 })).status, 401);
  const blocked = await call("/api/session", { method: "POST", body: { action: "staff-login", login_id: "OPR2", pin: "777666" } });
  assert.equal(blocked.status, 403);

  const self = await call("/api/accounts", {
    method: "PATCH", cookie: sessions.admin,
    body: { id: admin.id, full_name: "Admin Utama", role: "operator", active: true }
  });
  assert.equal(self.status, 400);
  const selfOff = await call("/api/accounts", {
    method: "PATCH", cookie: sessions.admin,
    body: { id: admin.id, full_name: "Admin Utama", active: false }
  });
  assert.equal(selfOff.status, 400);
});

test("logout menghapus sesi; POST lintas-origin ditolak; body rusak -> 400", async () => {
  const before = await call("/api/session", { cookie: sessions.spv });
  assert.equal(before.status, 200);
  assert.equal(before.data.role, "supervisor");

  const cross = await call("/api/session", { method: "POST", cookie: sessions.spv, origin: "https://evil.example", body: { action: "logout" } });
  assert.equal(cross.status, 403);

  const out = await call("/api/session", { method: "POST", cookie: sessions.spv, body: { action: "logout" } });
  assert.equal(out.status, 200);
  assert.match(out.response.headers.get("Set-Cookie"), /Max-Age=0/);
  assert.equal((await call("/api/session", { cookie: sessions.spv })).status, 401);

  const broken = await worker.fetch(new Request(ORIGIN + "/api/session", {
    method: "POST", headers: { Origin: ORIGIN, "Content-Type": "application/json" }, body: "{bukan json"
  }), env);
  assert.equal(broken.status, 400);
});
