# Garbarata OPS

Pencatatan operasional garbarata (doking/undocking) Airside Operation – Sultan Hasanuddin.
Berjalan di **Cloudflare Workers + D1 + Static Assets**.

## Struktur

| Lokasi | Isi |
| --- | --- |
| `public/` | Frontend statis: `index.html`, `sw.js`, `manifest.webmanifest`, `assets/`, `_headers`. **Hanya folder ini yang dipublikasikan.** |
| `worker.js` | API (`/api/*`) dan halaman `/setup-admin`. File statis tidak melewati Worker. |
| `migrations/` | Skema D1 (SQLite). |
| `tests/` | Tes end-to-end Worker (`npm test`). |
| `legacy-netlify/` | Kode lama Netlify/Supabase, hanya arsip. Tidak dipakai dan tidak ikut di-deploy. |

## Deploy ke Cloudflare

```bash
npm install
npx wrangler login
npm run db:migrate:remote   # membuat tabel di D1
npm run deploy
```

Lalu **segera** buka `https://<alamat-worker-anda>/setup-admin` untuk membuat Admin pertama
(ID login + PIN 6–12 digit). Halaman ini otomatis menutup setelah Admin pertama dibuat,
tetapi sebelum itu siapa pun yang membukanya lebih dulu bisa menjadi Admin.

Admin lalu menambah operator/supervisor di menu **Pengelolaan User**. Semua peran masuk
dengan **ID login dan PIN**. Setelah 5 kali PIN salah, akun dikunci 15 menit. Mengganti PIN,
mengubah peran, atau menonaktifkan akun langsung mengakhiri sesi akun tersebut.

Jika tabel sudah pernah dibuat manual di dashboard Cloudflare, cek dulu isinya:

```bash
npx wrangler d1 execute garbarata-ops-db --remote --command "SELECT name, sql FROM sqlite_master WHERE type='table'"
```

## Pengembangan lokal

```bash
npm run db:migrate:local
npm run dev
npm test
```

## Catatan

- Data lama di Netlify/Supabase tidak diimpor ke D1.
- PIN disimpan sebagai hash PBKDF2 (100.000 iterasi, batas maksimum Cloudflare Workers).
- Sesi berlaku 5 jam lewat cookie `HttpOnly` + `Secure`; hak akses selalu diperiksa di server.
